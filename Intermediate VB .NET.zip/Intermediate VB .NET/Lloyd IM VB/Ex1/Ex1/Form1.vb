﻿Public Class Form1

    Private Sub cboYear_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        Dim intYear As Integer = CInt(cboYear.SelectedItem.ToString())
        Dim xmas As New Date(intYear, 12, 25)
        lblOut.Text = "In " & intYear & ", Christmas is on " &
                                xmas.ToString("dddd")
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        For i As Integer = Now.Year + 50 To Now.Year - 50 Step -1
            cboYear.Items.Add(i.ToString())
        Next
        cboYear.SelectedItem = Now.Year.ToString()
    End Sub

End Class
