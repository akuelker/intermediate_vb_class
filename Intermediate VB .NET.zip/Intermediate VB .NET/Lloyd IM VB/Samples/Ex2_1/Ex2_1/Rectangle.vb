﻿Public Class Rectangle
    Private recHgt As Integer
    Private recWdt As Integer

    Sub New()
        recHgt = 1
        recWdt = 1
    End Sub
    Sub New(sameSize As Integer)
        recHgt = sameSize
        recWdt = sameSize
    End Sub
    Sub New(h As Integer, w As Integer)
        recHgt = h
        recWdt = w
    End Sub
    Property Height As Integer
        Get
            Return recHgt
        End Get
        Set(value As Integer)
            recHgt = value
        End Set
    End Property
    Property Width As Integer
        Get
            Return recWdt
        End Get
        Set(value As Integer)
            recWdt = value
        End Set
    End Property
    ReadOnly Property Area As Integer
        Get
            Return recHgt * recWdt
        End Get

    End Property
End Class
