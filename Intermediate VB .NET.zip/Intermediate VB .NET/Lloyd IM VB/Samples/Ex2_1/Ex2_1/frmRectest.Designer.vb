﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRectest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtH = New System.Windows.Forms.TextBox()
        Me.txtW = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtArea = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btnArea = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn1
        '
        Me.btn1.Location = New System.Drawing.Point(12, 12)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(207, 23)
        Me.btn1.TabIndex = 0
        Me.btn1.Text = "1 X 1"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(47, 109)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Height:"
        '
        'txtH
        '
        Me.txtH.Location = New System.Drawing.Point(92, 106)
        Me.txtH.Name = "txtH"
        Me.txtH.Size = New System.Drawing.Size(79, 20)
        Me.txtH.TabIndex = 4
        '
        'txtW
        '
        Me.txtW.Location = New System.Drawing.Point(92, 147)
        Me.txtW.Name = "txtW"
        Me.txtW.Size = New System.Drawing.Size(79, 20)
        Me.txtW.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(47, 150)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Width:"
        '
        'txtArea
        '
        Me.txtArea.Location = New System.Drawing.Point(92, 218)
        Me.txtArea.Name = "txtArea"
        Me.txtArea.Size = New System.Drawing.Size(79, 20)
        Me.txtArea.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(47, 221)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Area:"
        '
        'btn2
        '
        Me.btn2.Location = New System.Drawing.Point(12, 41)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(207, 23)
        Me.btn2.TabIndex = 1
        Me.btn2.Text = "4 X 4"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Location = New System.Drawing.Point(12, 70)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(207, 23)
        Me.btn3.TabIndex = 2
        Me.btn3.Text = "4 X 5"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'btnArea
        '
        Me.btnArea.Location = New System.Drawing.Point(12, 180)
        Me.btnArea.Name = "btnArea"
        Me.btnArea.Size = New System.Drawing.Size(207, 23)
        Me.btnArea.TabIndex = 3
        Me.btnArea.Text = "Get Area"
        Me.btnArea.UseVisualStyleBackColor = True
        '
        'frmRectest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(231, 262)
        Me.Controls.Add(Me.btnArea)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.txtArea)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtW)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtH)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn1)
        Me.Name = "frmRectest"
        Me.Text = "Rectangle Test"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtH As System.Windows.Forms.TextBox
    Friend WithEvents txtW As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtArea As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents btn3 As System.Windows.Forms.Button
    Friend WithEvents btnArea As System.Windows.Forms.Button

End Class
