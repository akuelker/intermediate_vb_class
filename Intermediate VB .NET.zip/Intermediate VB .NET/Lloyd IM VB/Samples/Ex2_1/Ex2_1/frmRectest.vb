﻿Public Class frmRectest
    Private Sub btn1_Click(sender As System.Object, e As System.EventArgs) Handles btn1.Click
        Dim rec1 As New Rectangle()
        txtH.Text = rec1.Height.ToString
        txtW.Text = rec1.Width.ToString
        txtArea.Text = rec1.Area.ToString
    End Sub
    Private Sub btn2_Click(sender As System.Object, e As System.EventArgs) Handles btn2.Click
        Dim rec1 As New Rectangle(4)
        txtH.Text = rec1.Height.ToString
        txtW.Text = rec1.Width.ToString
        txtArea.Text = rec1.Area.ToString
    End Sub
    Private Sub btn3_Click(sender As System.Object, e As System.EventArgs) Handles btn3.Click
        Dim rec1 As New Rectangle(4, 5)
        txtH.Text = rec1.Height.ToString
        txtW.Text = rec1.Width.ToString
        txtArea.Text = rec1.Area.ToString
    End Sub
    Private Sub btnArea_Click(sender As System.Object, e As System.EventArgs) Handles btnArea.Click
        Dim rec1 As New Rectangle(CInt(txtH.Text), CInt(txtW.Text))
        txtArea.Text = rec1.Area.ToString
    End Sub
End Class
