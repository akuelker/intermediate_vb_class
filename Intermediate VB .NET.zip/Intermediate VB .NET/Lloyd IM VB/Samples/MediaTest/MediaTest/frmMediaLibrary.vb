﻿Public Class frmMediaLibrary
    Dim mediaList As ArrayList = New ArrayList(8)
    Private Sub MediaLibrary_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        mediaList.Add(New Book("Sam's Teach Yourself Java", 2003, _
          "Rogers Candenhead", "Nonfiction"))
        mediaList.Add(New Book("Objects First with Java", 2003, _
          "David J. Barnes", "Nonfiction"))
        mediaList.Add(New Book("Core Java Vol. 1", 2003, _
          "Cay S. Horstmann", "Nonfiction"))
        mediaList.Add(New Book("Java: How to Program", 2003, _
          "H. M. Deitel", "Nonfiction"))
        mediaList.Add(New Magazine("CFO", 2003, "Fall", 12))
        mediaList.Add(New Magazine("InfoWorld", 2003, "October", 42))
        mediaList.Add(New Magazine("InfoWorld", 2003, "September", 35))
        mediaList.Add(New Magazine("CFO", 2003, "September", 11))

        For Each m As Media In mediaList
            'If (TypeOf m Is Magazine) Then

            'ElseIf (TypeOf m Is Book) Then

            'End If
            m.Completed = True
            lstMedia.Items.Add(m.GetInfo())
        Next
    End Sub
End Class