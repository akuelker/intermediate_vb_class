﻿Public Class Media
    ' fields
    Private title As String
    Private year As Integer
    Private read As Boolean
    ' constructors
    Sub New(title As String, year As Integer)
        Me.title = title
        Me.year = year
        read = False
    End Sub
    ' props
    Property PubTitle() As String
        Get
            Return title
        End Get
        Set(ByVal value As String)
            title = value
        End Set
    End Property

    Property PubYear() As Integer
        Get
            Return year
        End Get
        Set(ByVal value As Integer)
            year = value
        End Set
    End Property

    Property Completed() As Boolean
        Get
            Return read
        End Get
        Set(ByVal value As Boolean)
            read = value
        End Set
    End Property
    ' methods
    Overridable Function GetInfo() As String
        Dim info As String = ""
        info &= "Title: " & title & vbCrLf
        info &= "Publication Year: " & year & vbCrLf
        info &= "Completed: " & read & vbCrLf
        Return info
    End Function
End Class
