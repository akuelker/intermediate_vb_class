﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMediaTest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkMagazine = New System.Windows.Forms.RadioButton()
        Me.chkBook = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblPubDate = New System.Windows.Forms.Label()
        Me.lblHeaderPubDate = New System.Windows.Forms.Label()
        Me.lblRead = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnRead = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblSummary = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkMagazine)
        Me.GroupBox1.Controls.Add(Me.chkBook)
        Me.GroupBox1.Location = New System.Drawing.Point(26, 39)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Choose Media"
        '
        'chkMagazine
        '
        Me.chkMagazine.AutoSize = True
        Me.chkMagazine.Location = New System.Drawing.Point(114, 29)
        Me.chkMagazine.Name = "chkMagazine"
        Me.chkMagazine.Size = New System.Drawing.Size(71, 17)
        Me.chkMagazine.TabIndex = 1
        Me.chkMagazine.TabStop = True
        Me.chkMagazine.Text = "Magazine"
        Me.chkMagazine.UseVisualStyleBackColor = True
        '
        'chkBook
        '
        Me.chkBook.AutoSize = True
        Me.chkBook.Location = New System.Drawing.Point(19, 29)
        Me.chkBook.Name = "chkBook"
        Me.chkBook.Size = New System.Drawing.Size(50, 17)
        Me.chkBook.TabIndex = 0
        Me.chkBook.TabStop = True
        Me.chkBook.Text = "Book"
        Me.chkBook.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(26, 172)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Title:"
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Location = New System.Drawing.Point(119, 172)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(0, 13)
        Me.lblTitle.TabIndex = 2
        '
        'lblYear
        '
        Me.lblYear.AutoSize = True
        Me.lblYear.Location = New System.Drawing.Point(119, 220)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(0, 13)
        Me.lblYear.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(26, 220)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Year:"
        '
        'lblPubDate
        '
        Me.lblPubDate.AutoSize = True
        Me.lblPubDate.Location = New System.Drawing.Point(119, 262)
        Me.lblPubDate.Name = "lblPubDate"
        Me.lblPubDate.Size = New System.Drawing.Size(0, 13)
        Me.lblPubDate.TabIndex = 6
        '
        'lblHeaderPubDate
        '
        Me.lblHeaderPubDate.AutoSize = True
        Me.lblHeaderPubDate.Location = New System.Drawing.Point(26, 262)
        Me.lblHeaderPubDate.Name = "lblHeaderPubDate"
        Me.lblHeaderPubDate.Size = New System.Drawing.Size(88, 13)
        Me.lblHeaderPubDate.TabIndex = 5
        Me.lblHeaderPubDate.Text = "Publication Date:"
        '
        'lblRead
        '
        Me.lblRead.AutoSize = True
        Me.lblRead.Location = New System.Drawing.Point(119, 306)
        Me.lblRead.Name = "lblRead"
        Me.lblRead.Size = New System.Drawing.Size(0, 13)
        Me.lblRead.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(26, 306)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(36, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Read:"
        '
        'btnRead
        '
        Me.btnRead.Location = New System.Drawing.Point(29, 334)
        Me.btnRead.Name = "btnRead"
        Me.btnRead.Size = New System.Drawing.Size(154, 23)
        Me.btnRead.TabIndex = 9
        Me.btnRead.Text = "Click when you've read it"
        Me.btnRead.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(261, 39)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 13)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Summary:"
        '
        'lblSummary
        '
        Me.lblSummary.AutoSize = True
        Me.lblSummary.Location = New System.Drawing.Point(261, 70)
        Me.lblSummary.Name = "lblSummary"
        Me.lblSummary.Size = New System.Drawing.Size(0, 13)
        Me.lblSummary.TabIndex = 11
        '
        'frmMediaTest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(455, 369)
        Me.Controls.Add(Me.lblSummary)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.btnRead)
        Me.Controls.Add(Me.lblRead)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.lblPubDate)
        Me.Controls.Add(Me.lblHeaderPubDate)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmMediaTest"
        Me.Text = "MediaTest"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents chkMagazine As System.Windows.Forms.RadioButton
    Friend WithEvents chkBook As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblYear As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblPubDate As System.Windows.Forms.Label
    Friend WithEvents lblHeaderPubDate As System.Windows.Forms.Label
    Friend WithEvents lblRead As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnRead As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblSummary As System.Windows.Forms.Label
End Class
