﻿Public Class frmMediaTest

    Dim aBook As Book = New Book("Sam's Teach yourself Java", 2003, "Roger Candenhead", "Nonfiction")
    Dim aMag As Magazine = New Magazine("Jolly Journal", 2001, "September", 18)
    Private Sub chkBook_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkBook.CheckedChanged
        Me.lblSummary.Text = aBook.GetInfo()
        Me.lblTitle.Text = aBook.PubTitle
        Me.lblYear.Text = aBook.PubYear
        Me.lblHeaderPubDate.Visible = False
        Me.lblPubDate.Visible = False
        Me.lblRead.Text = aBook.Completed
    End Sub

    Private Sub chkMagazine_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkMagazine.CheckedChanged
        Me.lblSummary.Text = aMag.GetInfo()
        Me.lblTitle.Text = aMag.PubTitle
        Me.lblYear.Text = aMag.PubYear
        Me.lblHeaderPubDate.Visible = True
        Me.lblPubDate.Visible = True
        Me.lblHeaderPubDate.Text = "Publication Date:"
        Dim castMag As Magazine = aMag ' convert to mag
        Me.lblPubDate.Text = castMag.PubDate.ToString
        Me.lblRead.Text = aMag.Completed
    End Sub

    Private Sub btnRead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRead.Click
        aBook.Completed = True
        aMag.Completed = True
        Me.lblRead.Text = aBook.Completed
        Me.lblRead.Text = aMag.Completed
    End Sub

    Private Sub frmMediaTest_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class