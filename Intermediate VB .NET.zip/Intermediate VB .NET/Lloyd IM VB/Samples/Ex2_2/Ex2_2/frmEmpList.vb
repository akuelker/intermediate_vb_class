﻿Public Class frmEmpList

    Dim emps As New ArrayList(20)

    Private Sub frmEmpList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        emps.Add(New Employee("Mike Brady", "Boss", 25))
        emps.Add(New Employee("Mary Brady", "Captain", 23))
        emps.Add(New Employee("Minnie Brady", "Admiral", 2))
        emps.Add(New Employee("Mark Brady", "Petty Officer", 3))
        emps.Add(New Employee("Melborne Brady", "Ensign", 4))
        emps.Add(New Employee("Missy Brady", "Bum", 5))
        emps.Add(New Employee("Maddie Brady", "Teacher", 6))
        emps.Add(New Employee("Mort Brady", "Principal", 67))
        emps.Add(New Employee("Molly Brady", "Driver", 8))
        emps.Add(New Employee("Mindy Brady", "Butler", 9))
        emps.Add(New Employee("Marcus Brady", "Chef"))
        emps.Add(New Employee("Merrigold Brady", "Loan Officer"))
        emps.Add(New Employee("Meg Brady", "Manager", 11))
        emps.Add(New Employee("Mandy Brady", "VP", 33))
        emps.Add(New Employee("Manny Brady", "AVP", 41))
        emps.Add(New Employee("Murray Brady", "Director", 1))
        emps.Add(New Employee("Meagan Brady", "Minister", 3))
        emps.Add(New Employee("Millie Brady", "Dancer", 3))
        emps.Add(New Employee("Melissa Brady", "Actress", 3))
        emps.Add(New Employee("Marissa Brady", "Ballet Instructor", 3))

        RefreshForm()
    End Sub

    Private Sub RefreshForm()
        Dim dblPayroll As Double = 0

        For i As Integer = 0 To emps.Count - 1
            Dim emp As Employee = emps(i)
            dblPayroll += emp.GetWeeklyPay()
        Next

        dgvEmps.DataSource = Nothing
        dgvEmps.DataSource = emps

        dgvEmps.Columns("HourlyRate").DefaultCellStyle.Format = "C"
        dgvEmps.Columns("WeeklyPay").DefaultCellStyle.Format = "C"
        dgvEmps.Columns("HourlyRate").DefaultCellStyle.Alignment = _
            DataGridViewContentAlignment.MiddleRight
        dgvEmps.Columns("WeeklyPay").DefaultCellStyle.Alignment = _
           DataGridViewContentAlignment.MiddleRight
        dgvEmps.Columns("EmployeeLogin").Visible = False

        lblPayroll.Text = "Payroll =" & Format(dblPayroll, "C")
        lblCount.Text = "Count =" & emps.Count

    End Sub

    Private Sub btnRaise_Click(sender As System.Object, e As System.EventArgs) Handles btnRaise.Click
        For i As Integer = 0 To emps.Count - 1
            Dim emp As Employee = emps(i)
            emp.RaisePay(0.1)
        Next

        RefreshForm()
    End Sub
End Class