﻿Public Class empText

    Dim emp1 As New Employee("Warren Buffet", "Janitor")
    ' Dim emp1 As New Employee("Warren Buffet", "Janitor", 30)
    Private Sub btnRaisePay_Click(sender As System.Object, e As System.EventArgs) Handles btnRaisePay.Click
        emp1.RaisePay(0.1)
        txtHrlyRate.Text = Format(emp1.HourlyRate, "C")
        txtWeeklyPAy.Text = Format(emp1.GetWeeklyPay(), "C")
    End Sub

    Private Sub btnChangeTitle_Click(sender As System.Object, e As System.EventArgs) Handles btnChangeTitle.Click
        emp1.EmployeeTitle = txtTitle.Text
    End Sub

    Private Sub btnGetInfo_Click(sender As System.Object, e As System.EventArgs) Handles btnGetInfo.Click
        MsgBox(emp1.GetInfo())
    End Sub


    Private Sub empText_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        txtName.Text = emp1.EmployeeName
        txtTitle.Text = emp1.EmployeeTitle
        txtHrlyRate.Text = Format(emp1.HourlyRate, "C")
        txtWeeklyPAy.Text = Format(emp1.GetWeeklyPay(), "C")
        txtLogin.Text = emp1.EmployeeLogin
    End Sub

    Private Sub btnLogin_Click(sender As System.Object, e As System.EventArgs) Handles btnLogin.Click
        emp1.EmployeeLogin = txtLogin.Text
    End Sub
End Class