﻿Public Class Employee
    Public Const MAX_RATE As Double = 50
    Private empName As String
    Private empTitle As String
    Private empRate As Double
    Private empLogin As String

    Sub New(name As String, title As String)
        empName = name
        empTitle = title
        empRate = 10
        empLogin = Mid(empName, 1, 3) & Mid(empTitle, 1, 3)
    End Sub
    Sub New(name As String, title As String, rate As Double)
        empName = name
        empTitle = title
        If rate > MAX_RATE Then
            empRate = MAX_RATE
        Else
            empRate = rate
        End If
        empLogin = Mid(empName, 1, 3) & Mid(empTitle, 1, 3)
    End Sub
    ReadOnly Property EmployeeName As String
        Get
            Return empName
        End Get
    End Property
    Property EmployeeTitle As String
        Get
            Return empTitle
        End Get
        Set(value As String)
            empTitle = value
        End Set
    End Property
    ReadOnly Property HourlyRate As Double
        Get
            Return empRate
        End Get
    End Property
    ReadOnly Property WeeklyPay As Double
        Get
            Return GetWeeklyPay()
        End Get
    End Property
    Property EmployeeLogin As String
        Get
            Return empLogin
        End Get
        Set(value As String)
            empLogin = value
        End Set
    End Property
    Sub RaisePay(raisePercentage As Double)
        Dim tempRate = empRate * (1 + raisePercentage)
        If tempRate > MAX_RATE Then
            ' MsgBox(empName & " is maxxed out")
            empRate = MAX_RATE
        Else
            empRate = tempRate
        End If
    End Sub

    Function GetInfo() As String
        Dim info As String = ""
        info &= "Name: " & EmployeeName & vbCrLf
        info &= "Title: " & EmployeeTitle & vbCrLf
        info &= "Hourly Rate: " & Format(empRate, "C") & vbCrLf
        info &= "Weekly Pay: " & Format(GetWeeklyPay(), "C") & vbCrLf
        info &= "Login ID: " & EmployeeLogin & vbCrLf
        Return info
    End Function

    Function GetWeeklyPay() As Double
        Return empRate * 40
    End Function
    Function GetWeeklyPay(inthours) As Double
        Return empRate * inthours
    End Function
End Class
