﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class empText
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.txtLogin = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtWeeklyPAy = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnGetInfo = New System.Windows.Forms.Button()
        Me.btnChangeTitle = New System.Windows.Forms.Button()
        Me.txtHrlyRate = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnRaisePay = New System.Windows.Forms.Button()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnLogin
        '
        Me.btnLogin.Location = New System.Drawing.Point(33, 289)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(134, 23)
        Me.btnLogin.TabIndex = 27
        Me.btnLogin.Text = "Chane Login"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'txtLogin
        '
        Me.txtLogin.Location = New System.Drawing.Point(83, 163)
        Me.txtLogin.Name = "txtLogin"
        Me.txtLogin.Size = New System.Drawing.Size(100, 20)
        Me.txtLogin.TabIndex = 26
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(39, 167)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(36, 13)
        Me.Label5.TabIndex = 25
        Me.Label5.Text = "Login:"
        '
        'txtWeeklyPAy
        '
        Me.txtWeeklyPAy.Location = New System.Drawing.Point(83, 131)
        Me.txtWeeklyPAy.Name = "txtWeeklyPAy"
        Me.txtWeeklyPAy.Size = New System.Drawing.Size(100, 20)
        Me.txtWeeklyPAy.TabIndex = 24
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 135)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 13)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Weely Pay:"
        '
        'btnGetInfo
        '
        Me.btnGetInfo.Location = New System.Drawing.Point(33, 257)
        Me.btnGetInfo.Name = "btnGetInfo"
        Me.btnGetInfo.Size = New System.Drawing.Size(134, 26)
        Me.btnGetInfo.TabIndex = 22
        Me.btnGetInfo.Text = "Get Info"
        Me.btnGetInfo.UseVisualStyleBackColor = True
        '
        'btnChangeTitle
        '
        Me.btnChangeTitle.Location = New System.Drawing.Point(33, 228)
        Me.btnChangeTitle.Name = "btnChangeTitle"
        Me.btnChangeTitle.Size = New System.Drawing.Size(134, 26)
        Me.btnChangeTitle.TabIndex = 21
        Me.btnChangeTitle.Text = "Change Title"
        Me.btnChangeTitle.UseVisualStyleBackColor = True
        '
        'txtHrlyRate
        '
        Me.txtHrlyRate.Location = New System.Drawing.Point(83, 92)
        Me.txtHrlyRate.Name = "txtHrlyRate"
        Me.txtHrlyRate.Size = New System.Drawing.Size(100, 20)
        Me.txtHrlyRate.TabIndex = 20
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 96)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 13)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "Hourly Rate:"
        '
        'txtTitle
        '
        Me.txtTitle.Location = New System.Drawing.Point(83, 52)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(100, 20)
        Me.txtTitle.TabIndex = 18
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(45, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Title:"
        '
        'btnRaisePay
        '
        Me.btnRaisePay.Location = New System.Drawing.Point(33, 199)
        Me.btnRaisePay.Name = "btnRaisePay"
        Me.btnRaisePay.Size = New System.Drawing.Size(134, 26)
        Me.btnRaisePay.TabIndex = 16
        Me.btnRaisePay.Text = "Raise Pay 10%"
        Me.btnRaisePay.UseVisualStyleBackColor = True
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(83, 12)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(37, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Name:"
        '
        'empText
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(198, 328)
        Me.Controls.Add(Me.btnLogin)
        Me.Controls.Add(Me.txtLogin)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtWeeklyPAy)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnGetInfo)
        Me.Controls.Add(Me.btnChangeTitle)
        Me.Controls.Add(Me.txtHrlyRate)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtTitle)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnRaisePay)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label1)
        Me.Name = "empText"
        Me.Text = "empText"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnLogin As System.Windows.Forms.Button
    Friend WithEvents txtLogin As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtWeeklyPAy As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnGetInfo As System.Windows.Forms.Button
    Friend WithEvents btnChangeTitle As System.Windows.Forms.Button
    Friend WithEvents txtHrlyRate As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnRaisePay As System.Windows.Forms.Button
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
