﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEmpList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvEmps = New System.Windows.Forms.DataGridView()
        Me.btnRaise = New System.Windows.Forms.Button()
        Me.lblPayroll = New System.Windows.Forms.Label()
        Me.lblCount = New System.Windows.Forms.Label()
        CType(Me.dgvEmps, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvEmps
        '
        Me.dgvEmps.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvEmps.Location = New System.Drawing.Point(12, 12)
        Me.dgvEmps.Name = "dgvEmps"
        Me.dgvEmps.Size = New System.Drawing.Size(491, 265)
        Me.dgvEmps.TabIndex = 0
        '
        'btnRaise
        '
        Me.btnRaise.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRaise.Location = New System.Drawing.Point(372, 292)
        Me.btnRaise.Name = "btnRaise"
        Me.btnRaise.Size = New System.Drawing.Size(131, 34)
        Me.btnRaise.TabIndex = 1
        Me.btnRaise.Text = "Raise Pay 10%"
        Me.btnRaise.UseVisualStyleBackColor = True
        '
        'lblPayroll
        '
        Me.lblPayroll.AutoSize = True
        Me.lblPayroll.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPayroll.Location = New System.Drawing.Point(12, 292)
        Me.lblPayroll.Name = "lblPayroll"
        Me.lblPayroll.Size = New System.Drawing.Size(73, 16)
        Me.lblPayroll.TabIndex = 2
        Me.lblPayroll.Text = "Payroll = "
        '
        'lblCount
        '
        Me.lblCount.AutoSize = True
        Me.lblCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCount.Location = New System.Drawing.Point(12, 325)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(59, 16)
        Me.lblCount.TabIndex = 3
        Me.lblCount.Text = "Count ="
        '
        'frmEmpList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(515, 347)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.lblPayroll)
        Me.Controls.Add(Me.btnRaise)
        Me.Controls.Add(Me.dgvEmps)
        Me.Name = "frmEmpList"
        Me.Text = "frmEmpList"
        CType(Me.dgvEmps, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvEmps As System.Windows.Forms.DataGridView
    Friend WithEvents btnRaise As System.Windows.Forms.Button
    Friend WithEvents lblPayroll As System.Windows.Forms.Label
    Friend WithEvents lblCount As System.Windows.Forms.Label
End Class
