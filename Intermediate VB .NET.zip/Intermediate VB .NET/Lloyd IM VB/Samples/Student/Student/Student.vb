﻿Public Class Student
    ' members variables (fields)
    Public Const maxCredits As Integer = 18
    Private studentID As String
    Private firstName As String
    Private lastName As String
    Private currCredits As Integer ' number of currently enrolled credits
    Private totalCredits As Integer ' number of earned credits in college

    ' constructors
    Sub New(studentID As String, first As String, last As String)
        Me.studentID = studentID
        firstName = first
        lastName = last
        currCredits = 0
        totalCredits = 0
    End Sub
    Sub New(studentID As String, first As String, last As String, _
                            transferCredits As Integer)
        Me.studentID = studentID
        firstName = first
        lastName = last
        currCredits = 0
        totalCredits = transferCredits
    End Sub
    ' properties(gets and sets)
    ReadOnly Property Id As String
        Get
            Return studentID
        End Get
    End Property
    ReadOnly Property FullName As String
        Get
            Return lastName & ", " & firstName
        End Get
    End Property
    ReadOnly Property Credits As Integer
        Get
            Return currCredits
        End Get
    End Property
    Property StudentFirstName As String
        Get
            Return firstName
        End Get
        Set(value As String)
            firstName = value
        End Set
    End Property
    Property StudentLastName As String
        Get
            Return lastName
        End Get
        Set(value As String)
            lastName = value
        End Set
    End Property
    Property TotalCreds As Integer
        Get
            Return totalCredits
        End Get
        Set(value As Integer)
            totalCredits = value
        End Set
    End Property

    ' methods(behaviors)
    Sub AddCredits(newCredits As Integer)
        If (TestCredits(currCredits + newCredits)) Then
            currCredits += newCredits
        End If
    End Sub
    Sub AddCredits()
        If (TestCredits(currCredits + 1)) Then
            currCredits += 1
        End If
    End Sub
    Private Function TestCredits(proposedCredits As Integer) As Boolean
        If (proposedCredits > maxCredits) Then
            MsgBox("Credit limit exceeded. See Advisor 555-5555")
            Return False
        Else
            Return True
        End If
    End Function

    Sub ResetCredits()
        totalCredits += currCredits
        currCredits = 0
    End Sub
    Function GetInfo() As String
        Dim info As String = ""
        info &= "Student ID: " & studentID & vbCrLf
        info &= "Name: " & FullName & vbCrLf
        info &= "Current Credits: " & currCredits & vbCrLf
        info &= "Total Credits: " & totalCredits & vbCrLf
        Return info
    End Function

End Class
