﻿Public Class frmStudentList

    Dim students As New ArrayList(12)

    Private Sub frmStudentList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        students.Add(New Student("A001", "Larry", "Limbo"))
        students.Add(New Student("A002", "Becky", "Blue", 30))
        students.Add(New Student("A003", "Simon", "Smith", 15))
        students.Add(New Student("A004", "Fanny", "Fargo"))
        students.Add(New Student("A005", "Pete", "Smith", 9))
        students.Add(New Student("A006", "Bill", "Bailey"))
        students.Add(New Student("A007", "John", "Long"))
        students.Add(New Student("A008", "Van", "Hill", 36))
        students.Add(New Student("A009", "Cindy", "Jones"))
        students.Add(New Student("A010", "Sean", "Childs"))
        students.Add(New Student("A011", "Marcy", "Michaels", 18))

        dgvStudents.DataSource = students
        '      dgvStudents.Columns("StudentFirstName").Visible = False
        '      dgvStudents.Columns("StudentLastName").Visible = False
        '      dgvStudents.Columns("Credits").DefaultCellStyle.Format = "C"
        '   dgvStudents.Columns("Credits").HeaderText = "Boom"

        lblCount.Text = "Count =" & students.Count

    End Sub

    Private Sub btnAddCredits_Click(sender As System.Object, e As System.EventArgs) Handles btnAddCredits.Click
        For i As Integer = 0 To students.Count - 1
            Dim stud As Student = students(i)
            stud.AddCredits(5)
        Next
        dgvStudents.Refresh()
    End Sub

    Private Sub btnAddStudent_Click(sender As System.Object, e As System.EventArgs) Handles btnAddStudent.Click
        students.Insert(0, New Student("A012", "Kim", "Casey", 12))
        lblCount.Text = "Count =" & students.Count
        dgvStudents.DataSource = Nothing
        dgvStudents.DataSource = students
    End Sub

    Private Sub btnChange_Click(sender As System.Object, e As System.EventArgs) Handles btnChange.Click
        students(0) = New Student("A013", "Kelly", "Casey", 12)
        dgvStudents.Refresh()
    End Sub

    Private Sub btnRemove_Click(sender As System.Object, e As System.EventArgs) Handles btnRemove.Click
        Try
            students.RemoveAt(0)
            dgvStudents.DataSource = Nothing
            dgvStudents.DataSource = students
        Catch ex As Exception
            MsgBox("No students to remove" & vbCrLf & ex.Message)
        End Try
      
    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        students.Clear()
        dgvStudents.DataSource = Nothing
        dgvStudents.DataSource = students
    End Sub
End Class