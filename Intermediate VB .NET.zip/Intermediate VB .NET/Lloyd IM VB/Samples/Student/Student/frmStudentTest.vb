﻿Public Class frmStudentTest

    'Dim stud1 As New Student("A001", "Bill", "Gates")
    Dim stud1 As New Student("A001", "Bill", "Gates", 34)

    Private Sub frmStudentTest_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        txtID.Text = stud1.Id
        txtName.Text = stud1.FullName
        txtCurrCredits.Text = stud1.Credits.ToString()
        txtTotalCredits.Text = stud1.TotalCreds.ToString()
        txtMaxCreds.Text = Student.maxCredits.ToString()
    End Sub
    Private Sub btnAdd5_Click(sender As System.Object, e As System.EventArgs) Handles btnAdd5.Click
        stud1.AddCredits(5)
        txtCurrCredits.Text = stud1.Credits.ToString()
    End Sub
    Private Sub btnReset_Click(sender As System.Object, e As System.EventArgs) Handles btnReset.Click
        stud1.ResetCredits()
        txtCurrCredits.Text = stud1.Credits.ToString()
        txtTotalCredits.Text = stud1.TotalCreds.ToString()
    End Sub
    Private Sub btnGetInfo_Click(sender As System.Object, e As System.EventArgs) Handles btnGetInfo.Click
        MsgBox(stud1.GetInfo(), , "Student Info")
    End Sub

    Private Sub btnAdd1_Click(sender As System.Object, e As System.EventArgs) Handles btnAdd1.Click
        stud1.AddCredits()
        txtCurrCredits.Text = stud1.Credits.ToString()
    End Sub
End Class
