﻿Public Class Form1

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim lblDays(42) As Label
        Dim intCols, intHeight, intWidth, intLeftBorder, intTopBorder As Integer
        intCols = 7
        intWidth = 32
        intHeight = 24
        intLeftBorder = 20
        intTopBorder = 55

        For i As Integer = 0 To 42
            Dim lblnew As New Label
            Dim intTop, intLeft As Integer
            lblnew.TextAlign = ContentAlignment.MiddleRight
            lblnew.Size = New Size(intWidth, intHeight)
            intTop = Math.Floor(i / intCols) * intHeight + intTopBorder
            intLeft = (i Mod intCols) * intWidth + intLeftBorder
            lblnew.Location = New Point(intLeft, intTop)
            lblDays(i) = lblnew
            Controls.Add(lblnew)
        Next

        Dim cal As Date = Now
        Dim intMonth As Integer = cal.Month
        Dim intDay As Integer = 0

        cal = New Date(Now.Year, Now.Month, 1)

        lblHeading.Text = cal.ToString("MMMM") & vbCrLf & cal.Year

        For i As Integer = DayOfWeek.Sunday To cal.DayOfWeek - 1
            intDay += 1
        Next

        Do While cal.Month = intMonth
            lblDays(intDay).Text = cal.Day
            If (cal.Day = Now.Day) Then
                lblDays(intDay).Font = New Font(lblDays(intDay).Font.Name,
                                                lblDays(intDay).Font.Size,
                                                FontStyle.Bold)
                lblDays(intDay).BorderStyle = BorderStyle.FixedSingle
                lblDays(intDay).ForeColor = Color.Blue
            End If
            intDay += 1
            cal = cal.AddDays(1)
        Loop

    End Sub
End Class
