﻿Public Class Form1

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'Dim bday As New Date(1969, 9, 16) ' New is a call 2 constructor
        Dim bday As Date = Now ' current date and time
        bday = bday.AddDays(3452) ' methods
        bday = bday.AddHours(321)
        lblSample.Text = bday.ToString() & vbCrLf
        lblSample.Text &= "Month: " & bday.Month & vbCrLf ' props
        lblSample.Text &= "Year: " & bday.Year & vbCrLf
        lblSample.Text &= "Day: " & bday.Day & vbCrLf
        lblSample.Text &= bday.ToString("dddd") & vbCrLf
    End Sub
End Class
