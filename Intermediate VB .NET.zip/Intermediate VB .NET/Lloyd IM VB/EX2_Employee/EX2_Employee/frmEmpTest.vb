﻿Public Class frmEmpTest

    Dim emp1 As New Employee("Bill Gates", "Janitor", 40)

    Private Sub frmEmpTest_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        txtLogin.Text = emp1.Login
        txtName.Text = emp1.employeeName
        txtTitle.Text = emp1.JobTitle
        txtRate.Text = emp1.Hourlyrate.ToString("C")
        txtWeekly.Text = emp1.GetWeeklyPay().ToString("C")
        dtpHireDate.Value = emp1.DateHired
        txtHours.Text = emp1.HoursWorked
    End Sub

    Private Sub btnRaise_Click(sender As System.Object, e As System.EventArgs) Handles btnRaise.Click
        emp1.RaisePay(0.1)
        txtRate.Text = emp1.Hourlyrate.ToString("C")
        txtWeekly.Text = emp1.GetWeeklyPay().ToString("C")
    End Sub

    Private Sub btnTitle_Click(sender As System.Object, e As System.EventArgs) Handles btnTitle.Click
        emp1.JobTitle = InputBox("Enter new Title")
        MsgBox("Title has been Changed")
        txtTitle.Text = emp1.JobTitle
    End Sub

    Private Sub btnInfo_Click(sender As System.Object, e As System.EventArgs) Handles btnInfo.Click
        MsgBox(emp1.GetInfo())
    End Sub

    Private Sub dtpHireDate_ValueChanged(sender As System.Object, e As System.EventArgs) Handles dtpHireDate.ValueChanged
        If emp1.DateHired.ToString("d") <>
                dtpHireDate.Value.ToString("d") Then
            emp1.DateHired = dtpHireDate.Value
            MsgBox("Hire date has been changed")
        End If
    End Sub

    Private Sub btnLogin_Click(sender As System.Object, e As System.EventArgs) Handles btnLogin.Click
        emp1.Login = InputBox("Enter new login")
        MsgBox("Login ID has been changed")
        txtLogin.Text = emp1.Login
    End Sub

    Private Sub btnPT_Click(sender As System.Object, e As System.EventArgs) Handles btnPT.Click
        emp1.HoursWorked = CDbl(txtHours.Text)
        txtWeekly.Text = emp1.GetWeeklyPay().ToString("C")
    End Sub
End Class
