﻿Public Class Employee
    Public Const MAX_PAY As Double = 50

    Private empName As String
    Private empTitle As String
    Private empHrlyRate As Double
    Private empHireDate As Date
    Private empLogin As String
    Private empHours As Double

    Sub New(name As String, title As String)
        empName = name
        empTitle = title
        empHrlyRate = 10
        empHireDate = Now
        empLogin = empName.Substring(0, 3) & empTitle.Substring(0, 3)
        empHours = 40
    End Sub
    Sub New(name As String, title As String, rate As Double)
        empName = name
        empTitle = title
        If rate < MAX_PAY Then
            empHrlyRate = rate
        Else
            empHrlyRate = MAX_PAY
        End If
        empHireDate = Now
        empLogin = empName.Substring(0, 3) & empTitle.Substring(0, 3)
        empHours = 40
    End Sub
    ReadOnly Property employeeName As String
        Get
            Return empName
        End Get
    End Property
    Property Login As String
        Get
            Return empLogin
        End Get
        Set(value As String)
            empLogin = value
        End Set
    End Property
    Property HoursWorked As Double
        Get
            Return empHours
        End Get
        Set(value As Double)
            empHours = value
        End Set
    End Property
    ReadOnly Property Hourlyrate As Double
        Get
            Return empHrlyRate
        End Get
    End Property
    ReadOnly Property WeeklyPay As Double
        Get
            Return GetWeeklyPay()
        End Get
    End Property
    Property JobTitle As String
        Get
            Return empTitle
        End Get
        Set(value As String)
            empTitle = value
        End Set
    End Property
    Property DateHired As Date
        Get
            Return empHireDate
        End Get
        Set(value As Date)
            empHireDate = value
        End Set
    End Property
    Sub RaisePay(hike As Double)
        Dim tempHrlyRate As Double = empHrlyRate * (1 + hike)
        If tempHrlyRate <= MAX_PAY Then
            empHrlyRate = tempHrlyRate
        Else
            empHrlyRate = MAX_PAY
            MsgBox("Max rate met and exceeded")
        End If
    End Sub

    Function GetInfo() As String
        Dim info As String = ""
        info &= "Name: " & empName & vbCrLf
        info &= "Login: " & empLogin & vbCrLf
        info &= "Title: " & empTitle & vbCrLf
        info &= "Rate: " & empHrlyRate.ToString("C") & vbCrLf
        info &= "Hours: " & empHours.ToString() & vbCrLf
        info &= "Weekly Pay: " & GetWeeklyPay().ToString("C") & vbCrLf
        info &= "Date Hired: " & empHireDate.ToString("d") & vbCrLf
        Return info
    End Function

    Function GetWeeklyPay() As Double
        Return empHours * empHrlyRate
    End Function


End Class
