﻿Public Class frmEmpList

    Dim emps As New ArrayList(20)

    Private Sub frmEmpList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        emps.Add(New Employee("Tom Thompson", "Accountant", 6.25))
        emps.Add(New Employee("Pete Peterson", "Programmer", 6.75))
        emps.Add(New Employee("Georgia Kennedy", "Director", 7.5))
        emps.Add(New Employee("Meredith Jones", "Accountant", 10.2))
        emps.Add(New Employee("Sammy Jones", "Accountant", 10.2))
        emps.Add(New Employee("Geraldine Jones", "Accountant", 10.2))
        emps.Add(New Employee("Jean Cummings", "Engineer", 9.75))
        emps.Add(New Employee("Michael Robbins", "Secretary", 7.5))
        emps.Add(New Employee("Polly Marks", "Secretary", 7.5))
        emps.Add(New Employee("Robert North", "Secretary", 9.5))
        emps.Add(New Employee("Cory Chambers", "Admin Asst", 10.5))
        emps.Add(New Employee("Isabel Thorne", "Instructor", 7.5))
        emps.Add(New Employee("Bob Green", "Sales Rep", 9.5))
        emps.Add(New Employee("Tommy Green", "Sales Rep", 9.5))
        emps.Add(New Employee("Mitch Green", "Sales Rep", 9.5))
        emps.Add(New Employee("Bart Green", "Sales Rep", 9.5))
        emps.Add(New Employee("Greg Green", "Sales Rep", 9.5))
        emps.Add(New Employee("Susie Green", "Sales Rep", 9.5))
        emps.Add(New Employee("Eric Green", "Sales Rep", 9.5))
        emps.Add(New Employee("Tonya Green", "Sales Rep", 9.5))
        RefreshForm()
    End Sub

    Private Sub btnRaise_Click(sender As System.Object, e As System.EventArgs) Handles btnRaise.Click
        For Each emp As Employee In emps
            emp.RaisePay(0.1)
        Next
        RefreshForm()
    End Sub

    Private Sub RefreshForm()
        dgvEmps.DataSource = Nothing
        dgvEmps.DataSource = emps
        'extra
        dgvEmps.Columns("Hourlyrate").DefaultCellStyle.Format = "C"
        dgvEmps.Columns("Hourlyrate").DefaultCellStyle.Alignment =
                 DataGridViewContentAlignment.MiddleRight
        dgvEmps.Columns("WeeklyPay").DefaultCellStyle.Format = "C"
        dgvEmps.Columns("WeeklyPay").DefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleRight
        dgvEmps.Columns("DateHired").DefaultCellStyle.Format = "d"
        dgvEmps.Columns("DateHired").DefaultCellStyle.Alignment =
              DataGridViewContentAlignment.MiddleRight
        dgvEmps.Columns("employeeName").HeaderText = "Name"
        'dgvEmps.Columns("Login").Visible = False

        Dim dblPayroll As Double = 0
        For Each emp As Employee In emps
            dblPayroll += emp.GetWeeklyPay()
        Next

        lblPayroll.Text = "Payroll = " & dblPayroll.ToString("C")
        lblCount.Text = "Count = " & emps.Count


    End Sub
End Class