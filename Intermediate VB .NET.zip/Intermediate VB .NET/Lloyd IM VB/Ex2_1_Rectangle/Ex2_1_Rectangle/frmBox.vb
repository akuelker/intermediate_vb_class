﻿Public Class frmBox

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim box1 As New Box3D()
        Dim info As String = ""
        info &= "H: " & box1.RecHeight.ToString & vbCrLf
        info &= "W: " & box1.RecWidth.ToString & vbCrLf
        info &= "D: " & box1.Depth.ToString & vbCrLf
        info &= "A: " & box1.GetArea.ToString & vbCrLf
        info &= "V: " & box1.getVolume().ToString & vbCrLf
        MsgBox(info)
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Dim box1 As New Box3D(4)
        Dim info As String = ""
        info &= "H: " & box1.RecHeight.ToString & vbCrLf
        info &= "W: " & box1.RecWidth.ToString & vbCrLf
        info &= "D: " & box1.Depth.ToString & vbCrLf
        info &= "A: " & box1.GetArea.ToString & vbCrLf
        info &= "V: " & box1.getVolume().ToString & vbCrLf
        MsgBox(info)
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Dim box1 As New Box3D(4, 5, 6)
        Dim info As String = ""
        info &= "H: " & box1.RecHeight.ToString & vbCrLf
        info &= "W: " & box1.RecWidth.ToString & vbCrLf
        info &= "D: " & box1.Depth.ToString & vbCrLf
        info &= "A: " & box1.GetArea.ToString & vbCrLf
        info &= "V: " & box1.getVolume().ToString & vbCrLf
        MsgBox(info)
    End Sub
End Class