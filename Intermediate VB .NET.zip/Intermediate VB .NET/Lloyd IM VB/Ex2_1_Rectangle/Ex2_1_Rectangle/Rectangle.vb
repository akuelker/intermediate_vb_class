﻿Public Class Rectangle
    Private recH As Integer
    Private recW As Integer

    Sub New()
        recH = 1
        recW = 1
    End Sub
    Sub New(sameSize As Integer)
        recH = sameSize
        recW = sameSize
    End Sub
    Sub New(h As Integer, w As Integer)
        recH = h
        recW = w
    End Sub

    Property RecHeight As Integer
        Get
            Return recH
        End Get
        Set(value As Integer)
            recH = value
        End Set
    End Property
    Property RecWidth As Integer
        Get
            Return recW
        End Get
        Set(value As Integer)
            recW = value
        End Set
    End Property

    Public Overridable Function GetArea() As Integer
        Return recH * recW
    End Function



End Class
