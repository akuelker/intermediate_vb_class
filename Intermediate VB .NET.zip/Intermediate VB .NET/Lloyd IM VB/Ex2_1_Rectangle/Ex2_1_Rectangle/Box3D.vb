﻿Public Class Box3D
    Inherits Rectangle

    Private boxDepth As Integer

    Sub New()
        MyBase.New()
        boxDepth = 1
    End Sub
    Sub New(sameSize As Integer)
        MyBase.New(sameSize)
        boxDepth = sameSize
    End Sub
    Sub New(h As Integer, w As Integer, d As Integer)
        MyBase.New(h, w)
        boxDepth = d
    End Sub

    Property Depth As Integer
        Get
            Return boxDepth
        End Get
        Set(value As Integer)
            boxDepth = value
        End Set
    End Property
    Function getVolume() As Integer
        Return MyBase.RecHeight * MyBase.RecWidth * Depth
    End Function

    Overrides Function GetArea() As Integer
        Return (MyBase.GetArea * 2) + (MyBase.RecWidth * Depth * 2) +
                                (MyBase.RecHeight * Depth * 2)
    End Function
End Class
