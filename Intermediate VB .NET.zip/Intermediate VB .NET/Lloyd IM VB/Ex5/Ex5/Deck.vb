﻿
Public Class Deck
    Private cards As ArrayList()

    Sub New(numCards As Integer)

    End Sub

    Sub Shuffle()

    End Sub

    Function GetACard() As Card
        Return New Card()
    End Function

End Class
