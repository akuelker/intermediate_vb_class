﻿
Public Class RuleEngine


    Function getPokerWinner(Hands As ArrayList, Players As ArrayList) As Player
        For Each hand As ArrayList In hands
            ' go thru rules to give a score for each hand
            ' 10 for royal flush, 9 for straight flush...
            ' compare numbers to see who won
        Next
        Return New Player
    End Function

    Function getBlackJackWinner(Hands As ArrayList, Players As ArrayList) As Player
        For Each hand As ArrayList In hands
            ' go thru rules to give a score for each hand 
            ' return bust or winner or push
        Next
        Return New Player
    End Function

    Function getBridgeWinner(Hands As ArrayList, Players As ArrayList) As Player
        For Each hand As ArrayList In hands
            ' go thru rules to give a score for each hand return winner
        Next
        Return New Player
    End Function



End Class
