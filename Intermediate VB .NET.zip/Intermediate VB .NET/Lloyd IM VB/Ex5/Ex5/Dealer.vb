﻿
Public Class Dealer
    Private dealerID As String
    Private hand As ArrayList

    Function DealCards(deck As Deck) As Card
        Return New Card
    End Function
End Class
