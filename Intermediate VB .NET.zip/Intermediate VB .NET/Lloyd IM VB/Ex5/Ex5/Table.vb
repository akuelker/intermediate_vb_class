﻿
Public Class Table
    Private TableID As String
    Private Players() As ArrayList
    Private availableSeats As Integer
    Private tableBetLimit As Double

    Sub New(typeOfGame As String)

    End Sub

End Class
