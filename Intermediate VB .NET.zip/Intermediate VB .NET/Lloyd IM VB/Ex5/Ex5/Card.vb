﻿
Public Class Card
    Private rank As Integer
    Private suit As String

    Sub New()

    End Sub

    Function GetCardFace() As String
        Return suit & "-" & rank
    End Function
End Class
