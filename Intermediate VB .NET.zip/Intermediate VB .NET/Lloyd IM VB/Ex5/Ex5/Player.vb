﻿
Public Class Player
    Private name As String
    Private bday As Date
    Private login As String
    Private balance As Double
    Private hand() As ArrayList

    ReadOnly Property playerCash As Double
        Get
            Return balance
        End Get
    End Property

    Sub Fold()

    End Sub

    Sub Bet(amt As Double)

    End Sub

    Sub Hit()

    End Sub
    Sub Split()

    End Sub
    Sub DoubleDown()

    End Sub
End Class
