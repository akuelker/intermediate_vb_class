﻿Public Class Student

    ' fields(attributes)
    Public Const MAX_CREDITS As Integer = 18

    Private studentID As String
    Private firstName As String
    Private lastName As String
    Private currCredits As Integer ' this semester
    Private totalCredits As String ' earned toward graduation
    ' constructors
    Sub New(id As String, first As String, last As String)
        studentID = id
        firstName = first
        lastName = last
        currCredits = 0
        totalCredits = 0
    End Sub
    Sub New(id As String, first As String, last As String,
            transferCredits As Integer)
        studentID = id
        firstName = first
        lastName = last
        currCredits = 0
        totalCredits = transferCredits
    End Sub
    ' properties(getters or setters)
    ReadOnly Property Id As String
        Get
            Return studentID
        End Get
    End Property
    ReadOnly Property FullName As String
        Get
            Return lastName & ", " & firstName
        End Get
    End Property
    ReadOnly Property Credits As Integer
        Get
            Return currCredits
        End Get
    End Property
    Property StudentFirstName As String
        Get
            Return firstName
        End Get
        Set(newfirst As String)
            firstName = newfirst
        End Set
    End Property
    Property StudentLastName As String
        Get
            Return lastName
        End Get
        Set(newlast As String)
            lastName = newlast
        End Set
    End Property
    Property TotalCreds As Integer
        Get
            Return totalCredits
        End Get
        Set(newTotal As Integer)
            totalCredits = newTotal
        End Set
    End Property
    ' methods (behaviors)
    Sub AddCredits(newCredits As Integer)
        Dim tempCredits As Integer = currCredits + newCredits
        If (tempCredits > MAX_CREDITS) Then
            MsgBox("Credit limit exceeded. See Advisor!")
        Else
            currCredits = tempCredits
        End If
    End Sub
    Sub AddCredits()
        AddCredits(1) ' call other add credits method passing a 1
    End Sub

    Sub ResetCredits()
        totalCredits = currCredits
        currCredits = 0
    End Sub

    Function GetInfo() As String
        Dim info As String = ""
        info &= "Student ID: " & studentID & vbCrLf
        info &= "Student Name: " & FullName & vbCrLf
        info &= "Current Credits: " & currCredits & vbCrLf
        info &= "Total Credits: " & totalCredits & vbCrLf
        Return info
    End Function
End Class
