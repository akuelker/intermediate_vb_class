﻿Public Class frmStudentList

    Dim students As New ArrayList(12)

    Private Sub frmStudentList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        students.Add(New Student("A001", "Larry", "Limbo"))
        students.Add(New Student("A002", "Becky", "Blue", 30))
        students.Add(New Student("A003", "Simon", "Smith", 15))
        students.Add(New Student("A004", "Fanny", "Fargo"))
        students.Add(New Student("A005", "Pete", "Smith", 9))
        students.Add(New Student("A006", "Bill", "Bailey"))
        students.Add(New Student("A007", "John", "Long"))
        students.Add(New Student("A008", "Van", "Hill", 36))
        students.Add(New Student("A009", "Cindy", "Jones"))
        students.Add(New Student("A010", "Sean", "Childs"))
        students.Add(New Student("A011", "Marcy", "Michaels", 18))

        dgvStudents.DataSource = students
        lblCount.Text = "Count = " & students.Count
    End Sub

    Private Sub btnaddCredits_Click(sender As System.Object, e As System.EventArgs) Handles btnaddCredits.Click
        'For i As Integer = 0 To students.Count - 1
        '    Dim stud As Student = students(i) ' implicit cast
        '    stud.AddCredits(5)
        'Next

        For Each stud As Student In students
            stud.AddCredits(5)
        Next

        ' if data changed must refresh
        dgvStudents.Refresh()
    End Sub

    Private Sub btnAddStudent_Click(sender As System.Object, e As System.EventArgs) Handles btnAddStudent.Click
        ' insert an element
        students.Insert(0, New Student("A012", "Kim", "Casey", 12))
        lblCount.Text = "Count = " & students.Count
        ' if size of arraylist changes must re-bind completely
        dgvStudents.DataSource = Nothing
        dgvStudents.DataSource = students
    End Sub

    Private Sub btnChange_Click(sender As System.Object, e As System.EventArgs) Handles btnChange.Click
        ' replace an element
        students(0) = New Student("A013", "Kelly", "Casey", 12)
        dgvStudents.Refresh()
    End Sub

    Private Sub btnRemove_Click(sender As System.Object, e As System.EventArgs) Handles btnRemove.Click
        Try
            ' remove an element
            students.RemoveAt(0)
            lblCount.Text = "Count = " & students.Count
            ' if size of arraylist changes must re-bind completely
            dgvStudents.DataSource = Nothing
            dgvStudents.DataSource = students
        Catch
            MsgBox("No more Students! Stop hitting that button!")
        End Try
    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        ' clear out all elements
        students.Clear()
       RefreshForm()
    End Sub

    Private Sub RefreshForm()
        lblCount.Text = "Count = " & students.Count
        ' if size of arraylist changes must re-bind completely
        dgvStudents.DataSource = Nothing
        dgvStudents.DataSource = students
    End Sub
End Class