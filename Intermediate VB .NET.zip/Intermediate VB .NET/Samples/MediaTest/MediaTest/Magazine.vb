﻿Public Class Magazine
    Inherits media 'to be child
    Private month As String
    Private issue As Integer


    Sub New(ByVal title As String, ByVal year As Integer, _
      ByVal month As String, ByVal issue As Integer)
        MyBase.New(title, year) 'calls parent constructor - must do this first
        Me.month = month
        Me.issue = issue
    End Sub

    ReadOnly Property PubDate() As String
        Get
            Return month & ", " & MyBase.PubYear

        End Get
    End Property

    Overrides Function GetInfo() As String
        Dim info As String = ""
        info &= MyBase.GetInfo
        info &= "Publication Month: " & month & vbCrLf
        info &= "Issue: " & issue & vbCrLf
        Return info
    End Function
End Class
