﻿Public Class Book
    Inherits media 'to be child
    Private author As String
    Private genre As String


    Sub New(ByVal title As String, ByVal year As Integer, _
      ByVal author As String, ByVal genre As String)
        MyBase.New(title, year) 'calls parent constructor - must do this first
        Me.author = author
        Me.genre = genre

    End Sub


    Overrides Function GetInfo() As String
        Dim info As String = ""
        info &= MyBase.GetInfo
        info &= "Author: " & author & vbCrLf
        info &= "Genre: " & genre & vbCrLf
        Return info
    End Function
End Class

