﻿Public Class Form1

    Dim emp As New Employee("Amanda Kuelker", "Winner", 64)

    Private Sub btnRaise_Click(sender As System.Object, e As System.EventArgs) Handles btnRaise.Click
        emp.RaisePay(10)
        txtPay.Text = Format(emp.HourlyPay, "c")

    End Sub

    Private Sub btnTitle_Click(sender As System.Object, e As System.EventArgs) Handles btnTitle.Click
        emp.JobTitle = InputBox("Enter new title", "new title")
        txtTitle.Text = emp.JobTitle
    End Sub

    Private Sub btnInfo_Click(sender As System.Object, e As System.EventArgs) Handles btnInfo.Click
        MsgBox(emp.GetInfo)
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        txtName.Text = emp.FullName
        txtTitle.Text = emp.JobTitle
        txtPay.Text = Format(emp.HourlyPay, "c")
    End Sub
End Class
