﻿Public Class frmEmployee
    Dim EmpList As New ArrayList(20)
    Private Sub frmEmployee_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        EmpList.Add(New Employee("Tom Thompson", "Accountant", 6.25))
        EmpList.Add(New Employee("Pete Peterson", "Programmer", 6.75))
        EmpList.Add(New Employee("Georgia Kennedy", "Director", 7.5))
        EmpList.Add(New Employee("Meredith Jones", "Accountant", 10.2))
        EmpList.Add(New Employee("Jean Cummings", "Engineer", 9.75))
        EmpList.Add(New Employee("Michael Robbins", "Secretary", 7.5))
        EmpList.Add(New Employee("Polly Marks", "Secretary", 7.5))
        EmpList.Add(New Employee("Robert North", "Secretary", 9.5))
        EmpList.Add(New Employee("Cory Chambers", "Admin Asst", 10.5))
        EmpList.Add(New Employee("Isabel Thorne", "Instructor", 7.5))
        EmpList.Add(New Employee("Harriet Green", "Sales Rep", 9.5))

        dgvStudent.DataSource = EmpList

        lblCount.Text = "Count = " & EmpList.Count


        Dim decTotalPay As Decimal, i As Integer
        For i = 0 To EmpList.Count - 1
            decTotalPay += CType(EmpList(i), Employee).GetWeeklyPay
        Next
        lblTotalPay.Text = "Total Pay = " & Format(decTotalPay, "c") & vbCrLf

    End Sub

    Private Sub btnRaise_Click(sender As System.Object, e As System.EventArgs) Handles btnRaise.Click

        Dim decTotalPay As Decimal, i As Integer
        For i = 0 To EmpList.Count - 1
            CType(EmpList(i), Employee).RaisePay(10)
            decTotalPay += CType(EmpList(i), Employee).GetWeeklyPay

        Next
        dgvStudent.Refresh()
        lblTotalPay.Text = "Total Pay = " & Format(decTotalPay, "c") & vbCrLf
    End Sub

    Private Sub RefreshForm()
        lblCount.Text = "Count = " & EmpList.Count
        dgvStudent.DataSource = Nothing
        dgvStudent.DataSource = EmpList
    End Sub
End Class

