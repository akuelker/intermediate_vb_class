﻿
Public Class Amanda

    Public Property Property1 As Integer
        Get

        End Get
        Set(value As Integer)

        End Set
    End Property

    Public Sub Method()

    End Sub

End Class
