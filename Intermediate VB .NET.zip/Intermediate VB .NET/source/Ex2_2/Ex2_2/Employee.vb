﻿Public Class Employee
    Private Shared maxPay As Decimal = 50
    Private empName As String
    Private jobDesc As String
    Private payRate As Decimal

    'constructors
    Sub New(id As String, title As String)
        empName = id
        jobDesc = title
        payRate = 10.0

    End Sub

    Sub New(id As String, title As String, pay As Decimal)
        empName = id
        jobDesc = title
        If (payRate > maxPay) Then
            payRate = maxPay
        Else
            payRate = pay
        End If
    End Sub

    'properties - getters and setters
    Property FullName As String
        Get
            Return empName
        End Get
        Set(value As String)
            empName = value
        End Set
    End Property

    Property HourlyPay As Decimal
        Get
            Return payRate
        End Get
        Set(value As Decimal)
            payRate = value
        End Set
    End Property


    Property JobTitle As String

        Get
            Return jobDesc

        End Get
        Set(value As String)
            jobDesc = value
        End Set
    End Property

    'methods

    Sub RaisePay(payInc As Decimal)
        Dim raise As Decimal = payRate * (1 + payInc / 100)
        If (raise > maxPay) Then
            payRate = maxPay
        Else
            payRate *= (1 + payInc)
        End If
    End Sub

    Function GetInfo() As String
        Dim info As String = ""
        info &= "Employee Name: " & empName & vbCrLf
        info &= "Employee Title: " & jobDesc & vbCrLf
        info &= "Current Pay Rate: " & Format(payRate, "c") & vbCrLf
        Return info
    End Function

    Function GetWeeklyPay() As Decimal
        Return payRate * 40
    End Function

    Function GetWeeklyPay(hrsWorked As Integer) As Decimal
        Return payRate * hrsWorked
    End Function
End Class
