﻿Public Class Form1

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim lblDays(42) As System.Windows.Forms.Label
        Dim intCols, intWidth, intHeight, intLeftBorder, intTopBorder As Integer
        intCols = 7
        intWidth = 32
        intHeight = 24
        intLeftBorder = 20
        intTopBorder = 55

        'add labels to the form and to the array
        For i As Integer = 0 To 42
            Dim lblNew As New System.Windows.Forms.Label
            Dim intTop, intLeft As Integer
            lblNew.TextAlign = ContentAlignment.MiddleRight
            lblNew.Size = New Size(intWidth, intHeight)
            intTop = Math.Floor(i / intCols) * intWidth + intLeftBorder
            intLeft = (i Mod intCols) * intWidth + intLeftBorder
            lblNew.Location = New Point(intLeft, intTop)
            lblDays(i) = lblNew
            Controls.Add(lblNew)
        Next
        'get current date
        Dim cal As Date = Now
        Dim intMonth As Integer = cal.Month
        Dim intDay As Integer = 0

        'reset to first of current month
        cal = New Date(Now.Year, intMonth, 1)

        lblHeading.Text = Format(cal, "MMM") + " " & cal.Year

        'move to the label that the first fell on
        For i As Integer = DayOfWeek.Sunday To cal.DayOfWeek - 1
            intDay += 1

        Next

        'loop thru current month
        Do While (cal.Month = intMonth)
            lblDays(intDay).Text = cal.Day
            If Int(cal.Day = Now.Day) Then
                lblDays(intDay).Font = New Font(lblDays(intDay).Font.Name,
                                                 lblDays(intDay).Font.Size,
                                                 FontStyle.Bold)
                lblDays(intDay).BorderStyle = BorderStyle.FixedSingle
                lblDays(intDay).ForeColor = Color.Blue
            End If
            intDay += 1
            cal = cal.AddDays(1)
        Loop
    End Sub
End Class
