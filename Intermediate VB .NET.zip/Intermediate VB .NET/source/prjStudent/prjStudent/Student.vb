﻿Public Class Student
    Private Shared maxCredits As Integer = 18
    Public Const MAX_CREDITS As Integer = 18


    'fields(attributes)
    Private studentID As String
    Private firstName As String
    Private lastName As String
    Private currCredits As String
    Private totalCredits As String

    'constructors
    'to initialize/set default
    Sub New(id As String, first As String, last As String)
        studentID = id
        firstName = first
        lastName = last
        currCredits = 0
        totalCredits = 0

    End Sub

    Sub New(id As String, first As String, last As String, transferCredits As Integer)
        studentID = id
        firstName = first
        lastName = last
        currCredits = 0
        totalCredits = transferCredits

    End Sub


    'properties(getters or setters)
    ReadOnly Property Id As String
        Get
            Return studentID
        End Get
    End Property

    ReadOnly Property FullName As String
        Get
            Return lastName & ", " & firstName
        End Get
    End Property

    ReadOnly Property Credits As Integer
        Get
            Return currCredits
        End Get
    End Property

    Property StudentFirstName As String

        Get
            Return firstName

        End Get
        Set(value As String)
            firstName = value
        End Set
    End Property

    Property StudentLastName As String

        Get
            Return lastName

        End Get
        Set(value As String)
            lastName = value
        End Set
    End Property
    Property TotalCreds As Integer

        Get
            Return totalCredits

        End Get
        Set(newTotal As Integer)
            totalCredits = newTotal
        End Set
    End Property
    'methods (behaviors)

    Sub AddCredits(newCredits As Integer)
        Dim tempCredits As Integer = currCredits + newCredits
        If (tempCredits > MAX_CREDITS) Then
            MsgBox("Credit limit exceeded")
        Else
            currCredits = tempCredits
        End If

    End Sub
    'method overloading - will use whichever one based on what is passed in
    Sub AddCredits()
        Dim tempCredits As Integer = currCredits + 1
        If (tempCredits > MAX_CREDITS) Then
            MsgBox("Credit limit exceeded")
        Else
            currCredits = tempCredits
        End If

    End Sub
    Sub ResetCredits()
        totalCredits = currCredits
        currCredits = 0
    End Sub

    Function GetInfo() As String
        Dim info As String = ""
        info &= "Student ID: " & studentID & vbCrLf
        info &= "Student Name: " & FullName & vbCrLf
        info &= "Current Credits: " & currCredits & vbCrLf
        info &= "Total Credits: " & totalCredits & vbCrLf
        Return info

    End Function
End Class
