﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStudentList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dvgStudents = New System.Windows.Forms.DataGridView()
        Me.btnAddStudent = New System.Windows.Forms.Button()
        Me.btnAddCredits = New System.Windows.Forms.Button()
        Me.btnChangeStudent = New System.Windows.Forms.Button()
        Me.btnRemoveStudent = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lblCount = New System.Windows.Forms.Label()
        CType(Me.dvgStudents, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dvgStudents
        '
        Me.dvgStudents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dvgStudents.Location = New System.Drawing.Point(13, 3)
        Me.dvgStudents.Name = "dvgStudents"
        Me.dvgStudents.Size = New System.Drawing.Size(546, 277)
        Me.dvgStudents.TabIndex = 0
        '
        'btnAddStudent
        '
        Me.btnAddStudent.Location = New System.Drawing.Point(576, 12)
        Me.btnAddStudent.Name = "btnAddStudent"
        Me.btnAddStudent.Size = New System.Drawing.Size(88, 36)
        Me.btnAddStudent.TabIndex = 1
        Me.btnAddStudent.Text = "Add Student"
        Me.btnAddStudent.UseVisualStyleBackColor = True
        '
        'btnAddCredits
        '
        Me.btnAddCredits.Location = New System.Drawing.Point(576, 68)
        Me.btnAddCredits.Name = "btnAddCredits"
        Me.btnAddCredits.Size = New System.Drawing.Size(88, 35)
        Me.btnAddCredits.TabIndex = 2
        Me.btnAddCredits.Text = "Add Credits"
        Me.btnAddCredits.UseVisualStyleBackColor = True
        '
        'btnChangeStudent
        '
        Me.btnChangeStudent.Location = New System.Drawing.Point(576, 121)
        Me.btnChangeStudent.Name = "btnChangeStudent"
        Me.btnChangeStudent.Size = New System.Drawing.Size(88, 39)
        Me.btnChangeStudent.TabIndex = 3
        Me.btnChangeStudent.Text = "Change Student"
        Me.btnChangeStudent.UseVisualStyleBackColor = True
        '
        'btnRemoveStudent
        '
        Me.btnRemoveStudent.Location = New System.Drawing.Point(576, 183)
        Me.btnRemoveStudent.Name = "btnRemoveStudent"
        Me.btnRemoveStudent.Size = New System.Drawing.Size(88, 37)
        Me.btnRemoveStudent.TabIndex = 4
        Me.btnRemoveStudent.Text = "Remove Student"
        Me.btnRemoveStudent.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(576, 245)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(88, 35)
        Me.btnClear.TabIndex = 5
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lblCount
        '
        Me.lblCount.AutoSize = True
        Me.lblCount.Location = New System.Drawing.Point(13, 313)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(35, 13)
        Me.lblCount.TabIndex = 6
        Me.lblCount.Text = "Count"
        '
        'frmStudentList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(676, 330)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnRemoveStudent)
        Me.Controls.Add(Me.btnChangeStudent)
        Me.Controls.Add(Me.btnAddCredits)
        Me.Controls.Add(Me.btnAddStudent)
        Me.Controls.Add(Me.dvgStudents)
        Me.Name = "frmStudentList"
        Me.Text = "frmStudentList"
        CType(Me.dvgStudents, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dvgStudents As System.Windows.Forms.DataGridView
    Friend WithEvents btnAddStudent As System.Windows.Forms.Button
    Friend WithEvents btnAddCredits As System.Windows.Forms.Button
    Friend WithEvents btnChangeStudent As System.Windows.Forms.Button
    Friend WithEvents btnRemoveStudent As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents lblCount As System.Windows.Forms.Label
End Class
