﻿Public Class frmStudTest

    Dim stud1 As New Student("A001", "Bill", "Gates")
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        txtID.Text = stud1.Id
        txtName.Text = stud1.FullName
        txtCurrCredits.Text = stud1.Credits.ToString
        txtTotalCredits.Text = stud1.TotalCreds

    End Sub

    Private Sub btnAddFive_Click(sender As System.Object, e As System.EventArgs) Handles btnAddFive.Click
        stud1.AddCredits(5)
        txtCurrCredits.Text = stud1.Credits.ToString
    End Sub

    Private Sub btnReset_Click(sender As System.Object, e As System.EventArgs) Handles btnReset.Click
        stud1.ResetCredits()
        txtCurrCredits.Text = stud1.Credits.ToString
        txtTotalCredits.Text = stud1.TotalCreds
    End Sub

    Private Sub btnShowStudent_Click(sender As System.Object, e As System.EventArgs) Handles btnShowStudent.Click
        MsgBox(stud1.GetInfo())
    End Sub

    Private Sub btnAddOne_Click(sender As System.Object, e As System.EventArgs) Handles btnAddOne.Click
        stud1.AddCredits()
        txtCurrCredits.Text = stud1.Credits.ToString
    End Sub
End Class
