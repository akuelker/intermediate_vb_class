﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStudTest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblID = New System.Windows.Forms.Label()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.txtCurrCredits = New System.Windows.Forms.TextBox()
        Me.lblCurrCredits = New System.Windows.Forms.Label()
        Me.txtTotalCredits = New System.Windows.Forms.TextBox()
        Me.lblTotalCredits = New System.Windows.Forms.Label()
        Me.btnAddFive = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnShowStudent = New System.Windows.Forms.Button()
        Me.btnAddOne = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(33, 28)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(18, 13)
        Me.lblID.TabIndex = 0
        Me.lblID.Text = "ID"
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(124, 28)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(100, 20)
        Me.txtID.TabIndex = 1
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(124, 54)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 3
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(33, 54)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(35, 13)
        Me.lblName.TabIndex = 2
        Me.lblName.Text = "Name"
        '
        'txtCurrCredits
        '
        Me.txtCurrCredits.Location = New System.Drawing.Point(124, 80)
        Me.txtCurrCredits.Name = "txtCurrCredits"
        Me.txtCurrCredits.Size = New System.Drawing.Size(100, 20)
        Me.txtCurrCredits.TabIndex = 5
        '
        'lblCurrCredits
        '
        Me.lblCurrCredits.AutoSize = True
        Me.lblCurrCredits.Location = New System.Drawing.Point(33, 80)
        Me.lblCurrCredits.Name = "lblCurrCredits"
        Me.lblCurrCredits.Size = New System.Drawing.Size(76, 13)
        Me.lblCurrCredits.TabIndex = 4
        Me.lblCurrCredits.Text = "Current Credits"
        '
        'txtTotalCredits
        '
        Me.txtTotalCredits.Location = New System.Drawing.Point(124, 106)
        Me.txtTotalCredits.Name = "txtTotalCredits"
        Me.txtTotalCredits.Size = New System.Drawing.Size(100, 20)
        Me.txtTotalCredits.TabIndex = 7
        '
        'lblTotalCredits
        '
        Me.lblTotalCredits.AutoSize = True
        Me.lblTotalCredits.Location = New System.Drawing.Point(33, 106)
        Me.lblTotalCredits.Name = "lblTotalCredits"
        Me.lblTotalCredits.Size = New System.Drawing.Size(66, 13)
        Me.lblTotalCredits.TabIndex = 6
        Me.lblTotalCredits.Text = "Total Credits"
        '
        'btnAddFive
        '
        Me.btnAddFive.Location = New System.Drawing.Point(21, 149)
        Me.btnAddFive.Name = "btnAddFive"
        Me.btnAddFive.Size = New System.Drawing.Size(102, 23)
        Me.btnAddFive.TabIndex = 8
        Me.btnAddFive.Text = "Add 5 Credits"
        Me.btnAddFive.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(21, 187)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(102, 23)
        Me.btnReset.TabIndex = 9
        Me.btnReset.Text = "Reset Credits"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnShowStudent
        '
        Me.btnShowStudent.Location = New System.Drawing.Point(21, 227)
        Me.btnShowStudent.Name = "btnShowStudent"
        Me.btnShowStudent.Size = New System.Drawing.Size(102, 23)
        Me.btnShowStudent.TabIndex = 10
        Me.btnShowStudent.Text = "Show Student"
        Me.btnShowStudent.UseVisualStyleBackColor = True
        '
        'btnAddOne
        '
        Me.btnAddOne.Location = New System.Drawing.Point(152, 149)
        Me.btnAddOne.Name = "btnAddOne"
        Me.btnAddOne.Size = New System.Drawing.Size(102, 23)
        Me.btnAddOne.TabIndex = 11
        Me.btnAddOne.Text = "Add 1 Credit"
        Me.btnAddOne.UseVisualStyleBackColor = True
        '
        'frmStudTest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.btnAddOne)
        Me.Controls.Add(Me.btnShowStudent)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnAddFive)
        Me.Controls.Add(Me.txtTotalCredits)
        Me.Controls.Add(Me.lblTotalCredits)
        Me.Controls.Add(Me.txtCurrCredits)
        Me.Controls.Add(Me.lblCurrCredits)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.lblID)
        Me.Name = "frmStudTest"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents txtCurrCredits As System.Windows.Forms.TextBox
    Friend WithEvents lblCurrCredits As System.Windows.Forms.Label
    Friend WithEvents txtTotalCredits As System.Windows.Forms.TextBox
    Friend WithEvents lblTotalCredits As System.Windows.Forms.Label
    Friend WithEvents btnAddFive As System.Windows.Forms.Button
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents btnShowStudent As System.Windows.Forms.Button
    Friend WithEvents btnAddOne As System.Windows.Forms.Button

End Class
