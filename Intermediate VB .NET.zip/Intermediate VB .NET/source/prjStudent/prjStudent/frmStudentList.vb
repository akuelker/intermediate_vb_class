﻿Public Class frmStudentList

    Dim students As New ArrayList(12) '0-11, allocating memory up front and saving time. dynamic

    Private Sub frmStudentList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        students.Add(New Student("A001", "Audrey", "Verstreater"))
        'add to zero because it is the next open spot
        students.Add(New Student("A002", "Bradley", "Kuelker", 30))
        students.Add(New Student("A003", "Simon", "Smith", 15))
        students.Add(New Student("A004", "Fanny", "Fargo"))
        students.Add(New Student("A005", "Pete", "Smith", 9))
        students.Add(New Student("A006", "Bill", "Bailey"))
        students.Add(New Student("A007", "John", "Long"))
        students.Add(New Student("A008", "Van", "Hill", 36))
        students.Add(New Student("A009", "Cindy", "Jones"))
        students.Add(New Student("A010", "Sean", "Childs"))
        students.Add(New Student("A011", "Marcy", "Michaels", 18))
        'bind gridview and array together
        dvgStudents.DataSource = students


        lblCount.Text = "Count = " & students.Count
    End Sub

    Private Sub btnAddCredits_Click(sender As System.Object, e As System.EventArgs) Handles btnAddCredits.Click
        ' For i As Integer = 0 To students.Count - 1 '0-10 , 11 elements
        ' Dim stud As Student = students(i) 'implicit cast from 0 to 10
        ' stud.AddCredits(5)
        'add 5 credits to each
        'Next

        'same as below, next is cleaner

        For Each stud As Student In students
            stud.AddCredits(5)
        Next
        'if data changes, must refresh to see changes in gridview
        dvgStudents.Refresh()


    End Sub

    Private Sub btnAddStudent_Click(sender As System.Object, e As System.EventArgs) Handles btnAddStudent.Click
        'insert an element, it will automatically reshuffle to put element wherever you want in array
        students.Insert(0, New Student("A012", "Kim", "Casey", 12))
        lblCount.Text = "Count = " & students.Count
        'if size of array changes you must rebind completely, can't just refresh
        dvgStudents.DataSource = Nothing
        dvgStudents.DataSource = students

    End Sub

    Private Sub btnChangeStudent_Click(sender As System.Object, e As System.EventArgs) Handles btnChangeStudent.Click
        'replace an element
        students(0) = New Student("A013", "Kelly", "Casey")
        dvgStudents.Refresh()
    End Sub

    Private Sub btnRemoveStudent_Click(sender As System.Object, e As System.EventArgs) Handles btnRemoveStudent.Click
        Try  'remove an element
            students.RemoveAt(0)
            RefreshForm()
        Catch
            MsgBox("No more students! Stop trying to remove!")
        End Try
    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        'clears out elements, not delete
        students.Clear()
        lblCount.Text = "Count = " & students.Count
        dvgStudents.DataSource = Nothing
        dvgStudents.DataSource = students

    End Sub

    Private Sub RefreshForm()
        lblCount.Text = "Count = " & students.Count
        dvgStudents.DataSource = Nothing
        dvgStudents.DataSource = students
    End Sub
End Class