﻿Public Class box
    Inherits Rectangle

    Private boxDepth As Integer

    Sub New()
        MyBase.New()
        boxDepth = 1
    End Sub

    Sub New(sameSize As Integer)
        MyBase.New(sameSize)
        boxDepth = sameSize
    End Sub

    Sub New(h As Integer, w As Integer, d As Integer)
        MyBase.New(h, w)
        boxDepth = d
    End Sub


    Property depth As Integer
        Get
            Return boxDepth
        End Get
        Set(value As Integer)
            boxDepth = value
        End Set
    End Property

    Overrides Function GetArea() As Integer
        Return (MyBase.GetArea * 2) + (2 * RecWidth * boxDepth) + (2 * RecHeight * boxDepth)
    End Function


    Function GetVolume() As Integer
        Return MyBase.RecHeight * MyBase.RecWidth * depth
    End Function
End Class
