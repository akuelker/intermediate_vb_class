﻿Public Class boxtest

    Private Sub btn1_Click(sender As System.Object, e As System.EventArgs) Handles btn1.Click
        Dim abox As New box()
        Dim msg As String = ""
        msg &= "Width " & abox.RecWidth & vbCrLf
        msg &= "Height " & abox.RecHeight & vbCrLf
        msg &= "Depth " & abox.depth & vbCrLf
        msg &= "Area " & abox.GetArea & vbCrLf
        msg &= "Volume " & abox.GetVolume & vbCrLf
        MsgBox(msg)
    End Sub

    Private Sub btn2_Click(sender As System.Object, e As System.EventArgs) Handles btn2.Click
        Dim abox As New box(4)
        Dim msg As String = ""
        msg &= "Width " & abox.RecWidth & vbCrLf
        msg &= "Height " & abox.RecHeight & vbCrLf
        msg &= "Depth " & abox.depth & vbCrLf
        msg &= "Area " & abox.GetArea & vbCrLf
        msg &= "Volume " & abox.GetVolume & vbCrLf
        MsgBox(msg)
    End Sub

    Private Sub btn3_Click(sender As System.Object, e As System.EventArgs) Handles btn3.Click
        Dim abox As New box(4, 5, 6)
        Dim msg As String = ""
        msg &= "Width " & abox.RecWidth & vbCrLf
        msg &= "Height " & abox.RecHeight & vbCrLf
        msg &= "Depth " & abox.depth & vbCrLf
        msg &= "Area " & abox.GetArea & vbCrLf
        msg &= "Volume " & abox.GetVolume & vbCrLf
        MsgBox(msg)
    End Sub
End Class