﻿Public Class Form1

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim bday As New Date(1990, 5, 12) 'new is call to constructor 
        bday = bday.AddDays(3452) 'methods
        lblSample.Text = bday.ToString() & vbCrLf
        lblSample.Text &= "Month: " & bday.Month & vbCrLf 'properties
        lblSample.Text &= "Year: " & bday.Year & vbCrLf
        lblSample.Text &= "Day: " & bday.Day & vbCrLf
        lblSample.Text &= bday.ToString("d") & vbCrLf
    End Sub
End Class
