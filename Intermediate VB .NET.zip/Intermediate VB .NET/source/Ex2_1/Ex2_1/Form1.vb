﻿Public Class Form1

    Private Sub btn1x1_Click(sender As System.Object, e As System.EventArgs) Handles btn1x1.Click
        Dim rec As New Rectangle()
        txtWidth.Text = rec.Width
        txtHeight.Text = rec.Height
        txtArea.Text = rec.Area
    End Sub

    Private Sub btn4x4_Click(sender As System.Object, e As System.EventArgs) Handles btn4x4.Click
        Dim rec As New Rectangle(4)
        txtWidth.Text = rec.Width
        txtHeight.Text = rec.Height
        txtArea.Text = rec.Area
    End Sub

    Private Sub btn4x5_Click(sender As System.Object, e As System.EventArgs) Handles btn4x5.Click
        Dim rec As New Rectangle(4, 5)
        txtWidth.Text = rec.Width
        txtHeight.Text = rec.Height
        txtArea.Text = rec.Area
    End Sub

    Private Sub btnArea_Click(sender As System.Object, e As System.EventArgs) Handles btnArea.Click
        If IsNumeric(txtHeight.Text) And IsNumeric(txtWidth.Text) Then
            Dim rec As New Rectangle()
            rec.Width = txtWidth.Text
            rec.Height = txtHeight.Text
            txtArea.Text = rec.Area
        Else
            MsgBox("Numeric values only, please!!!")
        End If
    End Sub
End Class
