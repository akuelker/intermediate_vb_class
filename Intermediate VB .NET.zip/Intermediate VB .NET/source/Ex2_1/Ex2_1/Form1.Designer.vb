﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn1x1 = New System.Windows.Forms.Button()
        Me.btn4x4 = New System.Windows.Forms.Button()
        Me.btn4x5 = New System.Windows.Forms.Button()
        Me.lblHeight = New System.Windows.Forms.Label()
        Me.txtHeight = New System.Windows.Forms.TextBox()
        Me.txtWidth = New System.Windows.Forms.TextBox()
        Me.lblWidth = New System.Windows.Forms.Label()
        Me.btnArea = New System.Windows.Forms.Button()
        Me.txtArea = New System.Windows.Forms.TextBox()
        Me.lblArea = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn1x1
        '
        Me.btn1x1.Location = New System.Drawing.Point(52, 13)
        Me.btn1x1.Name = "btn1x1"
        Me.btn1x1.Size = New System.Drawing.Size(158, 23)
        Me.btn1x1.TabIndex = 0
        Me.btn1x1.Text = "1x1"
        Me.btn1x1.UseVisualStyleBackColor = True
        '
        'btn4x4
        '
        Me.btn4x4.Location = New System.Drawing.Point(52, 42)
        Me.btn4x4.Name = "btn4x4"
        Me.btn4x4.Size = New System.Drawing.Size(158, 23)
        Me.btn4x4.TabIndex = 1
        Me.btn4x4.Text = "4x4"
        Me.btn4x4.UseVisualStyleBackColor = True
        '
        'btn4x5
        '
        Me.btn4x5.Location = New System.Drawing.Point(52, 71)
        Me.btn4x5.Name = "btn4x5"
        Me.btn4x5.Size = New System.Drawing.Size(158, 23)
        Me.btn4x5.TabIndex = 2
        Me.btn4x5.Text = "4x5"
        Me.btn4x5.UseVisualStyleBackColor = True
        '
        'lblHeight
        '
        Me.lblHeight.AutoSize = True
        Me.lblHeight.Location = New System.Drawing.Point(92, 118)
        Me.lblHeight.Name = "lblHeight"
        Me.lblHeight.Size = New System.Drawing.Size(38, 13)
        Me.lblHeight.TabIndex = 3
        Me.lblHeight.Text = "Height"
        '
        'txtHeight
        '
        Me.txtHeight.Location = New System.Drawing.Point(138, 118)
        Me.txtHeight.Name = "txtHeight"
        Me.txtHeight.Size = New System.Drawing.Size(100, 20)
        Me.txtHeight.TabIndex = 4
        '
        'txtWidth
        '
        Me.txtWidth.Location = New System.Drawing.Point(138, 144)
        Me.txtWidth.Name = "txtWidth"
        Me.txtWidth.Size = New System.Drawing.Size(100, 20)
        Me.txtWidth.TabIndex = 6
        '
        'lblWidth
        '
        Me.lblWidth.AutoSize = True
        Me.lblWidth.Location = New System.Drawing.Point(92, 144)
        Me.lblWidth.Name = "lblWidth"
        Me.lblWidth.Size = New System.Drawing.Size(35, 13)
        Me.lblWidth.TabIndex = 5
        Me.lblWidth.Text = "Width"
        '
        'btnArea
        '
        Me.btnArea.Location = New System.Drawing.Point(52, 186)
        Me.btnArea.Name = "btnArea"
        Me.btnArea.Size = New System.Drawing.Size(158, 23)
        Me.btnArea.TabIndex = 7
        Me.btnArea.Text = "Display Area"
        Me.btnArea.UseVisualStyleBackColor = True
        '
        'txtArea
        '
        Me.txtArea.Location = New System.Drawing.Point(138, 230)
        Me.txtArea.Name = "txtArea"
        Me.txtArea.Size = New System.Drawing.Size(100, 20)
        Me.txtArea.TabIndex = 9
        '
        'lblArea
        '
        Me.lblArea.AutoSize = True
        Me.lblArea.Location = New System.Drawing.Point(92, 230)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(29, 13)
        Me.lblArea.TabIndex = 8
        Me.lblArea.Text = "Area"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.txtArea)
        Me.Controls.Add(Me.lblArea)
        Me.Controls.Add(Me.btnArea)
        Me.Controls.Add(Me.txtWidth)
        Me.Controls.Add(Me.lblWidth)
        Me.Controls.Add(Me.txtHeight)
        Me.Controls.Add(Me.lblHeight)
        Me.Controls.Add(Me.btn4x5)
        Me.Controls.Add(Me.btn4x4)
        Me.Controls.Add(Me.btn1x1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn1x1 As System.Windows.Forms.Button
    Friend WithEvents btn4x4 As System.Windows.Forms.Button
    Friend WithEvents btn4x5 As System.Windows.Forms.Button
    Friend WithEvents lblHeight As System.Windows.Forms.Label
    Friend WithEvents txtHeight As System.Windows.Forms.TextBox
    Friend WithEvents txtWidth As System.Windows.Forms.TextBox
    Friend WithEvents lblWidth As System.Windows.Forms.Label
    Friend WithEvents btnArea As System.Windows.Forms.Button
    Friend WithEvents txtArea As System.Windows.Forms.TextBox
    Friend WithEvents lblArea As System.Windows.Forms.Label

End Class
