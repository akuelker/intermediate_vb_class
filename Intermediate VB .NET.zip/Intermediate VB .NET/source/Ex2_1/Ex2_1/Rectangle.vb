﻿Public Class Rectangle
    'fields/attributes
    Dim recHeight As Integer
    Dim recWidth As Integer

    'constructors

    'initialize, set default - 1st part
    Sub New()
        recHeight = 1
        recWidth = 1
    End Sub

    'overload constructor for square - 2nd part
    Sub New(value As Integer)
        recHeight = value
        recWidth = value
    End Sub

    'overload constructor for rectangle - 3rd part
    Sub New(h As Integer, w As Integer)
        recHeight = h
        recWidth = w
    End Sub

    'include accessors (getters and setters) to change and return property values

    Property Height As Integer

        Get
            Return recHeight

        End Get
        Set(value As Integer)
            recHeight = value
        End Set
    End Property

    Property Width As Integer

        Get
            Return recWidth

        End Get
        Set(value As Integer)
            recWidth = value
        End Set
    End Property

    ReadOnly Property Area As Integer

        Get
            Return recWidth * recHeight

        End Get
    End Property
End Class
