﻿
Public Class Table
    Private availableseats As Integer
    Private betlimit As Integer

    Public Sub newtable()

    End Sub

End Class
