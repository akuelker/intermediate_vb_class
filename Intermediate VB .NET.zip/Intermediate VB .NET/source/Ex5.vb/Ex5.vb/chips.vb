﻿
Public Class chips

    Public Sub betLimits()

    End Sub

    Public Sub payOut()

    End Sub

End Class
