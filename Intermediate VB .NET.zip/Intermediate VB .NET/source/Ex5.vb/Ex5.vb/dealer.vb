﻿
Public Class dealer

    Public Sub Deal()

    End Sub


    Public Sub Shuffle()

    End Sub

    Public Sub enforce()

    End Sub

    Public Sub TakeBet()

    End Sub

End Class
