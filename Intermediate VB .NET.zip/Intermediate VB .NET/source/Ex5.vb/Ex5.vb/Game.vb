﻿
Public Class Deck

    Public Property color As Integer
        Get

        End Get
        Set(value As Integer)

        End Set
    End Property

    Public Property suit As Integer
        Get

        End Get
        Set(value As Integer)

        End Set
    End Property

    Public Property number As Integer
        Get

        End Get
        Set(value As Integer)

        End Set
    End Property

    Public Sub add()

    End Sub

    Public Sub remove()

    End Sub

    Public Sub getacrd()

    End Sub

End Class
