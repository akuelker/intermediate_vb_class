﻿
Public Class Casino
    Private NoOfGames As Integer

    Public Sub CashOut()

    End Sub

    Public Sub CheckIn()

    End Sub

    Public Sub Poker()

    End Sub

    Public Sub Blackjack()

    End Sub

End Class
