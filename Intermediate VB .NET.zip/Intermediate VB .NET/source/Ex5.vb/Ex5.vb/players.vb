﻿
Public Class players
    Private Name As Integer

    Public Property NoOfPlayers As Integer
        Get

        End Get
        Set(value As Integer)

        End Set
    End Property

    Public Property cashamt As Integer
        Get

        End Get
        Set(value As Integer)

        End Set
    End Property

    Public Sub Bet()

    End Sub

    Public Sub Fold()

    End Sub

    Public Sub calls()

    End Sub

    Public Sub cashIn()

    End Sub

End Class
