﻿Public Class Box
    Inherits Rectangle

    Private boxDepth As Integer

    Sub New()
        MyBase.new()
        boxDepth = 1
    End Sub

    Sub New(ByVal size As Integer)
        MyBase.new(size)
        boxDepth = size
    End Sub

    Sub New(ByVal h As Integer, ByVal w As Integer, ByVal d As Integer)
        MyBase.new(h, w)
        boxDepth = d
    End Sub

    Public Property Depth As Integer
        Get
            Return boxDepth
        End Get
        Set(ByVal value As Integer)
            boxDepth = value
        End Set
    End Property

    Shadows ReadOnly Property Area As Integer
        Get
            Return (MyBase.Area * 2) + (Width * boxDepth * 2) + (Height * boxDepth * 2)
        End Get
    End Property

    ReadOnly Property Volume As Integer
        Get
            Return Height * Width * boxDepth
        End Get
    End Property

End Class
