﻿Public Class frmMediaTest

    Dim aBook As New Book("Sam's Teach yourself Java", 2003, "Roger Candenhead", "Nonfiction")
    Dim aMag As New Magazine("Jolly Journal", 2001, "September", 18)
    Private Sub chkBook_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkBook.CheckedChanged
        Me.lblSummary.Text = aBook.GetInfo()
        Me.lblTitle.Text = aBook.PubTitle
        Me.lblYear.Text = aBook.PubYear
        Me.lblHeaderPubDate.Visible = False
        Me.lblPubDate.Visible = False
        Me.lblRead.Text = aBook.Completed
    End Sub

    Private Sub chkMagazine_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkMagazine.CheckedChanged
        Me.lblSummary.Text = aMag.GetInfo()
        Me.lblTitle.Text = aMag.PubTitle
        Me.lblYear.Text = aMag.PubYear
        Me.lblHeaderPubDate.Visible = True
        Me.lblPubDate.Visible = True
        Me.lblHeaderPubDate.Text = "Publication Date:"
        Me.lblPubDate.Text = aMag.PubDate.ToString
        Me.lblRead.Text = aMag.Completed
    End Sub

    Private Sub btnRead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRead.Click
        aBook.Completed = True
        aMag.Completed = True
        Me.lblRead.Text = aBook.Completed
        Me.lblRead.Text = aMag.Completed
    End Sub
End Class