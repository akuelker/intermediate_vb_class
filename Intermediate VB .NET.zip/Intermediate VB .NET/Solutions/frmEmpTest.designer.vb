﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEmpTest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtHourlyPay = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnRaise = New System.Windows.Forms.Button()
        Me.btnChangeTitle = New System.Windows.Forms.Button()
        Me.btnInfo = New System.Windows.Forms.Button()
        Me.btnChangeLogin = New System.Windows.Forms.Button()
        Me.txtWeeklyPay = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(67, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Name:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(106, 28)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 1
        '
        'txtTitle
        '
        Me.txtTitle.Location = New System.Drawing.Point(106, 69)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(100, 20)
        Me.txtTitle.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(75, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Title:"
        '
        'txtHourlyPay
        '
        Me.txtHourlyPay.Location = New System.Drawing.Point(106, 108)
        Me.txtHourlyPay.Name = "txtHourlyPay"
        Me.txtHourlyPay.Size = New System.Drawing.Size(100, 20)
        Me.txtHourlyPay.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(44, 111)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Hourly Pay:"
        '
        'btnRaise
        '
        Me.btnRaise.Location = New System.Drawing.Point(27, 187)
        Me.btnRaise.Name = "btnRaise"
        Me.btnRaise.Size = New System.Drawing.Size(222, 23)
        Me.btnRaise.TabIndex = 6
        Me.btnRaise.Text = "Raise Pay 10%"
        Me.btnRaise.UseVisualStyleBackColor = True
        '
        'btnChangeTitle
        '
        Me.btnChangeTitle.Location = New System.Drawing.Point(27, 228)
        Me.btnChangeTitle.Name = "btnChangeTitle"
        Me.btnChangeTitle.Size = New System.Drawing.Size(222, 23)
        Me.btnChangeTitle.TabIndex = 7
        Me.btnChangeTitle.Text = "Change Title"
        Me.btnChangeTitle.UseVisualStyleBackColor = True
        '
        'btnInfo
        '
        Me.btnInfo.Location = New System.Drawing.Point(27, 267)
        Me.btnInfo.Name = "btnInfo"
        Me.btnInfo.Size = New System.Drawing.Size(222, 23)
        Me.btnInfo.TabIndex = 8
        Me.btnInfo.Text = "Info"
        Me.btnInfo.UseVisualStyleBackColor = True
        '
        'btnChangeLogin
        '
        Me.btnChangeLogin.Location = New System.Drawing.Point(27, 308)
        Me.btnChangeLogin.Name = "btnChangeLogin"
        Me.btnChangeLogin.Size = New System.Drawing.Size(222, 23)
        Me.btnChangeLogin.TabIndex = 9
        Me.btnChangeLogin.Text = "Change Login"
        Me.btnChangeLogin.UseVisualStyleBackColor = True
        '
        'txtWeeklyPay
        '
        Me.txtWeeklyPay.Location = New System.Drawing.Point(106, 147)
        Me.txtWeeklyPay.Name = "txtWeeklyPay"
        Me.txtWeeklyPay.Size = New System.Drawing.Size(100, 20)
        Me.txtWeeklyPay.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(38, 150)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(67, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Weekly Pay:"
        '
        'EmpTest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(275, 354)
        Me.Controls.Add(Me.txtWeeklyPay)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnChangeLogin)
        Me.Controls.Add(Me.btnInfo)
        Me.Controls.Add(Me.btnChangeTitle)
        Me.Controls.Add(Me.btnRaise)
        Me.Controls.Add(Me.txtHourlyPay)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtTitle)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label1)
        Me.Name = "EmpTest"
        Me.Text = "EmpTest"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtHourlyPay As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnRaise As System.Windows.Forms.Button
    Friend WithEvents btnChangeTitle As System.Windows.Forms.Button
    Friend WithEvents btnInfo As System.Windows.Forms.Button
    Friend WithEvents btnChangeLogin As System.Windows.Forms.Button
    Friend WithEvents txtWeeklyPay As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
