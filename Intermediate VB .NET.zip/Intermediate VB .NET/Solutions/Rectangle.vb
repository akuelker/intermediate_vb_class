﻿Public Class Rectangle
    Dim recHeight As Integer
    Dim recWidth As Integer

    Sub New()
        recHeight = 1
        recWidth = 1
    End Sub

    Sub New(ByVal side As Integer)
        recHeight = side
        recWidth = side
    End Sub

    Sub New(ByVal w As Integer, ByVal h As Integer)
        recHeight = h
        recWidth = w
    End Sub

    Property Height()
        Get
            Return recHeight
        End Get
        Set(ByVal value)
            recHeight = value
        End Set
    End Property

    Property Width()
        Get
            Return recWidth
        End Get
        Set(ByVal value)
            recWidth = value
        End Set
    End Property

    ReadOnly Property Area()
        Get
            Return recHeight * recWidth
        End Get
    End Property


End Class
