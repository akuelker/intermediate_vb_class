﻿Public Class frmStudentList

    Dim students As New ArrayList(12)

    Private Sub StudentList_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        students.Add(New Student("A001", "Larry", "Limbo"))
        students.Add(New Student("A002", "Becky", "Blue", 30))
        students.Add(New Student("A003", "Simon", "Smith", 15))
        students.Add(New Student("A004", "Fanny", "Fargo"))
        students.Add(New Student("A005", "Pete", "Smith", 9))
        students.Add(New Student("A006", "Bill", "Bailey"))
        students.Add(New Student("A007", "John", "Long"))
        students.Add(New Student("A008", "Van", "Hill", 36))
        students.Add(New Student("A009", "Cindy", "Jones"))
        students.Add(New Student("A010", "Sean", "Childs"))
        students.Add(New Student("A011", "Marcy", "Michaels", 18))
        dgvStudents.DataSource = students
        lblCount.Text = "Count = " & students.Count.ToString
    End Sub

    Private Sub btnAddStudent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddStudent.Click
        students.Insert(0, New Student("A012", "Kim", "Casey", 12))
        dgvStudents.DataSource = Nothing
        dgvStudents.DataSource = students
        lblCount.Text = "Count = " & students.Count.ToString
    End Sub

    Private Sub btnAddCredits_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddCredits.Click
        For i As Integer = 0 To students.Count - 1
            Dim s As Student = students(i)
            s.AddCredits(5)
        Next

        dgvStudents.Refresh()
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        students.Clear()
        dgvStudents.DataSource = Nothing
        dgvStudents.DataSource = students
        lblCount.Text = "Count = " & students.Count.ToString
    End Sub

    Private Sub btnChange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChange.Click
        students(0) = New Student("A013", "Kelly", "Casey", 12)
        dgvStudents.Refresh()
    End Sub

    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        students.RemoveAt(0)
        dgvStudents.DataSource = Nothing
        dgvStudents.DataSource = students
        lblCount.Text = "Count = " & students.Count.ToString
    End Sub
End Class