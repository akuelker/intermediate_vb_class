﻿Public Class frmRecTest
    Private Sub btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click
        Dim rec As New Rectangle()
        txtWidth.Text = rec.Width
        txtHeight.Text = rec.Height
        txtArea.Text = rec.Area
    End Sub

    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        Dim rec As New Rectangle(4)
        txtWidth.Text = rec.Width
        txtHeight.Text = rec.Height
        txtArea.Text = rec.Area
    End Sub

    Private Sub btn3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3.Click
        Dim rec As New Rectangle(4, 5)
        txtWidth.Text = rec.Width
        txtHeight.Text = rec.Height
        txtArea.Text = rec.Area
    End Sub

    Private Sub btnArea_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnArea.Click
        If IsNumeric(txtHeight.Text) And IsNumeric(txtWidth.Text) Then
            Dim rec As New Rectangle()
            rec.Width = txtWidth.Text
            rec.Height = txtHeight.Text
            txtArea.Text = rec.Area
        Else
            MsgBox("Numeric values only", 16, "Data entry error")
        End If

    End Sub
End Class