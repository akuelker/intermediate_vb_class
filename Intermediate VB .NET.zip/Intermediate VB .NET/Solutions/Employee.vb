﻿Public Class Employee
    Private Shared maxPay As Double = 50
    Private name As String
    Private title As String
    Private hourlyPay As Decimal
    Private login As String

    Sub New(ByVal name As String, ByVal title As String)
        Me.name = name
        Me.title = title
        hourlyPay = 10
        login = Mid(name, 1, 3) & Mid(title, 1, 3)
    End Sub

    Sub New(ByVal name As String, ByVal title As String, _
      ByVal hourlyPay As Decimal)
        Me.name = name
        Me.title = title

        If (hourlyPay > maxPay) Then
            Me.hourlyPay = maxPay
        Else
            Me.hourlyPay = hourlyPay
        End If
        login = Mid(name, 1, 3) & Mid(title, 1, 3)
    End Sub

    Property EmpName() As String
        Get
            Return name
        End Get
        Set(ByVal value As String)
            name = value
        End Set
    End Property

    Property JobTitle() As String
        Get
            Return title
        End Get
        Set(ByVal value As String)
            title = value
        End Set
    End Property

    Property HourlyRate() As Decimal
        Get
            Return hourlyPay
        End Get
        Set(ByVal value As Decimal)
            hourlyPay = value
        End Set
    End Property
    Property EmpLogin() As String
        Get
            Return login
        End Get
        Set(ByVal value As String)
            login = value
        End Set
    End Property

    Sub RaisePay(ByVal raisePercent As Decimal)
        Dim tempHourlyPay As Double = hourlyPay * (1 + raisePercent)
        If (tempHourlyPay > maxPay) Then
            hourlyPay = maxPay
        Else
            hourlyPay = tempHourlyPay
        End If
    End Sub

    Function GetWeeklyPay() As Double
        Return 40 * hourlyPay
    End Function

    Function GetWeeklyPay(ByVal hours As Integer) As Double
        Return hours * hourlyPay
    End Function

    Function GetInfo() As String
        Dim info As String
        info = EmpName & vbCrLf
        info &= JobTitle & vbCrLf
        info &= Format(HourlyRate, "c") & vbCrLf
        info &= EmpLogin
        Return info
    End Function

End Class
