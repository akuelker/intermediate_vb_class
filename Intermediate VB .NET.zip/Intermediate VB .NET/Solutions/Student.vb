﻿Public Class Student
    Private Shared maxCredits As Integer = 18
    Private studentId As String
    Private firstName As String
    Private lastName As String
    Private currCredits As Integer
    Private totalCredits As Integer

    Sub New(ByVal id As String, ByVal first As String, ByVal last As String)
        studentId = id
        firstName = first
        lastName = last
        currCredits = 0
        totalCredits = 0
    End Sub

    Sub New(ByVal id As String, ByVal first As String, ByVal last As String, ByVal transferCredits As Integer)
        studentId = id
        firstName = first
        lastName = last
        currCredits = 0
        totalCredits = transferCredits
    End Sub
    Shared ReadOnly Property MaxCreds() As Integer
        Get
            Return maxCredits
        End Get
    End Property

    ReadOnly Property ID As String
        Get
            Return studentId
        End Get
    End Property

    ReadOnly Property FullName As String
        Get
            Return lastName & ", " & firstName
        End Get
    End Property
    ReadOnly Property Credits() As Integer
        Get
            Return currCredits
        End Get
    End Property

    Property StudentFirstName() As String
        Get
            Return firstName
        End Get
        Set(ByVal value As String)
            firstName = value
        End Set
    End Property
    Property StudentLastName() As String
        Get
            Return lastName
        End Get
        Set(ByVal value As String)
            lastName = value
        End Set
    End Property
    Property TotalCreds() As Integer
        Get
            Return totalCredits
        End Get
        Set(ByVal value As Integer)
            totalCredits = value
        End Set
    End Property

    Sub AddCredits(ByVal newCredits As Integer)
        Dim tempCredits As Integer = currCredits + newCredits
        If tempCredits > maxCredits Then
            MsgBox("Credit limit exceeded")
        Else
            currCredits = tempCredits
        End If

    End Sub

    Sub AddCredits()
        Dim tempCredits As Integer = currCredits + 1
        If tempCredits > maxCredits Then
            MsgBox("Credit limit exceeded")
        Else
            currCredits = tempCredits
        End If

    End Sub
    Sub ResetCredits()
        totalCredits += currCredits
        currCredits = 0
    End Sub
    Function GetInfo()
        Dim info As String = ""
        info &= "ID: " & studentId & vbCrLf
        info &= "Name: " & FullName & vbCrLf
        info &= "Current Credits: " & currCredits & vbCrLf
        info &= "Total Credits: " & totalCredits & vbCrLf
        Return info
    End Function



End Class
