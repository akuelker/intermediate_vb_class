﻿Public Class frmChristmas
    Dim intYear As Integer
    Dim strWeekDay As String

    Private Sub Christmas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        For i As Integer = 2010 To 1900 Step -1
            cboYear.Items.Add(i.ToString())
        Next
    End Sub

    Private Sub cboYear_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        intYear = CInt(CStr(cboYear.SelectedItem))
        Dim aDate As New Date(intYear, 12, 25)
        strWeekDay = Format(aDate, "dddd")
        lblOutput.Text = "In " & intYear & ", Christmas Day occurs on " & strWeekDay
    End Sub
End Class