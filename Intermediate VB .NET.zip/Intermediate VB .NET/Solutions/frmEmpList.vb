﻿Public Class frmEmpList
    Private empList As New ArrayList(20)
    Private intCount As Integer

    Private Sub EmpList_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        empList.Add(New Employee("Tom Thompson", "Accountant", 6.25))
        empList.Add(New Employee("Pete Peterson", "Programmer", 6.75))
        empList.Add(New Employee("Georgia Kennedy", "Director", 7.5))
        empList.Add(New Employee("Meredith Jones", "Accountant", 10.2))
        empList.Add(New Employee("Jean Cummings", "Engineer", 9.75))
        empList.Add(New Employee("Michael Robbins", "Secretary", 7.5))
        empList.Add(New Employee("Polly Marks", "Secretary", 7.5))
        empList.Add(New Employee("Robert North", "Secretary", 9.5))
        empList.Add(New Employee("Cory Chambers", "Admin Asst", 10.5))
        empList.Add(New Employee("Isabel Thorne", "Instructor", 7.5))
        empList.Add(New Employee("Harriet Green", "Sales Rep", 9.5))


        dgvEmps.DataSource = empList

        Dim decTotalPay As Decimal, i As Integer
        For i = 0 To empList.Count - 1
            decTotalPay += CType(empList(i), Employee).GetWeeklyPay
        Next
        lblOutput.Text = "Total Pay = " & Format(decTotalPay, "c") & _
            vbCrLf & "Count = " & i
        intCount = i

    End Sub

    Private Sub btnRaise_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaise.Click
        Dim decTotalPay As Decimal
        For i As Integer = 0 To empList.Count - 1
            CType(empList(i), Employee).RaisePay(10)
            decTotalPay += CType(empList(i), Employee).GetWeeklyPay
        Next
        dgvEmps.Refresh()
        lblOutput.Text = "Total Pay = " & Format(decTotalPay, "c") & _
            vbCrLf & "Count = " & intCount
    End Sub
End Class