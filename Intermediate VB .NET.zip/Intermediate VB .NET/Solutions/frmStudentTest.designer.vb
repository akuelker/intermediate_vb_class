﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStudentTest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtCurrCredits = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTotalCredits = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnAddCredits = New System.Windows.Forms.Button()
        Me.btnResetCredits = New System.Windows.Forms.Button()
        Me.btnGetInfo = New System.Windows.Forms.Button()
        Me.txtMaxCredits = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnAdd1Credit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(108, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ID:"
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(136, 43)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(100, 20)
        Me.txtID.TabIndex = 1
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(136, 86)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(91, 89)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Name:"
        '
        'txtCurrCredits
        '
        Me.txtCurrCredits.Location = New System.Drawing.Point(136, 128)
        Me.txtCurrCredits.Name = "txtCurrCredits"
        Me.txtCurrCredits.Size = New System.Drawing.Size(100, 20)
        Me.txtCurrCredits.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(50, 131)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Current Credits:"
        '
        'txtTotalCredits
        '
        Me.txtTotalCredits.Location = New System.Drawing.Point(136, 171)
        Me.txtTotalCredits.Name = "txtTotalCredits"
        Me.txtTotalCredits.Size = New System.Drawing.Size(100, 20)
        Me.txtTotalCredits.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(60, 174)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(69, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Total Credits:"
        '
        'btnAddCredits
        '
        Me.btnAddCredits.Location = New System.Drawing.Point(12, 256)
        Me.btnAddCredits.Name = "btnAddCredits"
        Me.btnAddCredits.Size = New System.Drawing.Size(135, 23)
        Me.btnAddCredits.TabIndex = 8
        Me.btnAddCredits.Text = "Add Credits"
        Me.btnAddCredits.UseVisualStyleBackColor = True
        '
        'btnResetCredits
        '
        Me.btnResetCredits.Location = New System.Drawing.Point(12, 295)
        Me.btnResetCredits.Name = "btnResetCredits"
        Me.btnResetCredits.Size = New System.Drawing.Size(135, 23)
        Me.btnResetCredits.TabIndex = 9
        Me.btnResetCredits.Text = "Reset Credits"
        Me.btnResetCredits.UseVisualStyleBackColor = True
        '
        'btnGetInfo
        '
        Me.btnGetInfo.Location = New System.Drawing.Point(12, 335)
        Me.btnGetInfo.Name = "btnGetInfo"
        Me.btnGetInfo.Size = New System.Drawing.Size(135, 23)
        Me.btnGetInfo.TabIndex = 10
        Me.btnGetInfo.Text = "Get Info"
        Me.btnGetInfo.UseVisualStyleBackColor = True
        '
        'txtMaxCredits
        '
        Me.txtMaxCredits.Location = New System.Drawing.Point(136, 209)
        Me.txtMaxCredits.Name = "txtMaxCredits"
        Me.txtMaxCredits.Size = New System.Drawing.Size(100, 20)
        Me.txtMaxCredits.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(64, 212)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Max Credits:"
        '
        'btnAdd1Credit
        '
        Me.btnAdd1Credit.Location = New System.Drawing.Point(165, 256)
        Me.btnAdd1Credit.Name = "btnAdd1Credit"
        Me.btnAdd1Credit.Size = New System.Drawing.Size(135, 23)
        Me.btnAdd1Credit.TabIndex = 13
        Me.btnAdd1Credit.Text = "Add 1 Credits"
        Me.btnAdd1Credit.UseVisualStyleBackColor = True
        '
        'StudentTest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(312, 375)
        Me.Controls.Add(Me.btnAdd1Credit)
        Me.Controls.Add(Me.txtMaxCredits)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnGetInfo)
        Me.Controls.Add(Me.btnResetCredits)
        Me.Controls.Add(Me.btnAddCredits)
        Me.Controls.Add(Me.txtTotalCredits)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtCurrCredits)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.Label1)
        Me.Name = "StudentTest"
        Me.Text = "StudentTest"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtCurrCredits As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTotalCredits As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnAddCredits As System.Windows.Forms.Button
    Friend WithEvents btnResetCredits As System.Windows.Forms.Button
    Friend WithEvents btnGetInfo As System.Windows.Forms.Button
    Friend WithEvents txtMaxCredits As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnAdd1Credit As System.Windows.Forms.Button
End Class
