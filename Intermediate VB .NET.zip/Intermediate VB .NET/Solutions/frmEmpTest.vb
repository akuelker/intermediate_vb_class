﻿Public Class frmEmpTest

    Dim emp As New Employee("Biff Arfus", "Secretary", 15)

    Private Sub EmpTest_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtName.Text = emp.EmpName
        txtTitle.Text = emp.JobTitle
        txtHourlyPay.Text = Format(emp.HourlyRate, "c")
        txtWeeklyPay.Text = Format(emp.GetWeeklyPay(), "c")
    End Sub

    Private Sub btnRaise_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaise.Click
        emp.RaisePay(0.1)
        txtHourlyPay.Text = Format(emp.HourlyRate, "c")
        txtWeeklyPay.Text = Format(emp.GetWeeklyPay(), "c")
    End Sub

    Private Sub btnChangeTitle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChangeTitle.Click
        emp.JobTitle = InputBox("Enter the new title", "new title")
        txtTitle.Text = emp.JobTitle
    End Sub

    Private Sub btnInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInfo.Click
        MsgBox(emp.GetInfo())
    End Sub

    Private Sub btnChangeLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChangeLogin.Click
        emp.EmpLogin = InputBox("Enter new login ID")
    End Sub
End Class