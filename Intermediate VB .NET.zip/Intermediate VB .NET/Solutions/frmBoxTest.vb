﻿Public Class frmBoxTest

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim aBox As New Box()
        Dim msg As String = ""
        msg &= "Height: " & aBox.Height & vbCrLf
        msg &= "Width: " & aBox.Width & vbCrLf
        msg &= "Depth: " & aBox.Depth & vbCrLf
        msg &= "Area: " & aBox.Area & vbCrLf
        msg &= "Volume: " & aBox.Volume & vbCrLf
        MsgBox(msg)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim aBox As New Box(4)
        Dim msg As String = ""
        msg &= "Height: " & aBox.Height & vbCrLf
        msg &= "Width: " & aBox.Width & vbCrLf
        msg &= "Depth: " & aBox.Depth & vbCrLf
        msg &= "Area: " & aBox.Area & vbCrLf
        msg &= "Volume: " & aBox.Volume & vbCrLf
        MsgBox(msg)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim aBox As New Box(4, 5, 6)
        Dim msg As String = ""
        msg &= "Height: " & aBox.Height & vbCrLf
        msg &= "Width: " & aBox.Width & vbCrLf
        msg &= "Depth: " & aBox.Depth & vbCrLf
        msg &= "Area: " & aBox.Area & vbCrLf
        msg &= "Volume: " & aBox.Volume & vbCrLf
        MsgBox(msg)
    End Sub
End Class