﻿Public Class Magazine
    Private title As String
    Private year As Integer
    Private month As String
    Private issue As Integer
    Private read As Boolean

    Sub New(ByVal title As String, ByVal year As Integer, _
      ByVal month As String, ByVal issue As Integer)
        Me.title = title
        Me.year = year
        Me.month = month
        Me.issue = issue
        read = False
    End Sub
    Property PubTitle() As String
        Get
            Return title
        End Get
        Set(ByVal value As String)
            title = value
        End Set
    End Property

    Property PubYear() As Integer
        Get
            Return year
        End Get
        Set(ByVal value As Integer)
            year = value
        End Set
    End Property

    Property Completed() As Boolean
        Get
            Return read
        End Get
        Set(ByVal value As Boolean)
            read = value
        End Set
    End Property

    ReadOnly Property PubDate() As String
        Get
            Return month & ", " & year
        End Get
    End Property

    Function GetInfo() As String
        Dim info As String = ""
        info &= "Title: " & title & vbCrLf
        info &= "Publication Year: " & year & vbCrLf
        info &= "Publication Month: " & month & vbCrLf
        info &= "Issue: " & issue & vbCrLf
        Return info
    End Function
End Class
