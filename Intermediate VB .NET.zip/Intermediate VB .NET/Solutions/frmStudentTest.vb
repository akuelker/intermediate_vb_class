﻿Public Class frmStudentTest
    Dim stud As New Student("A001", "Bill", "Gates")
    'Dim stud As New Student("A002", "Warren", "Buffet", 30)

    Private Sub StudentTest_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtID.Text = stud.ID
        txtName.Text = stud.FullName
        txtCurrCredits.Text = stud.Credits.ToString
        txtTotalCredits.Text = stud.TotalCreds.ToString
        txtMaxCredits.Text = Student.MaxCreds
    End Sub

    Private Sub btnAddCredits_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddCredits.Click
        stud.AddCredits(5)
        txtCurrCredits.Text = stud.Credits.ToString
    End Sub

    Private Sub btnResetCredits_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetCredits.Click
        stud.ResetCredits()
        txtCurrCredits.Text = stud.Credits.ToString
        txtTotalCredits.Text = stud.TotalCreds.ToString
    End Sub

    Private Sub btnGetInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetInfo.Click
        MsgBox(stud.GetInfo(), , "Student Info")
    End Sub

    Private Sub btnAdd1Credit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd1Credit.Click
        stud.AddCredits(1)
        txtCurrCredits.Text = stud.Credits.ToString
    End Sub
End Class