﻿Public Class Book
    Private title As String
    Private year As Integer
    Private author As String
    Private genre As String
    Private read As Boolean

    Sub New(ByVal title As String, ByVal year As Integer, _
      ByVal author As String, ByVal genre As String)
        Me.title = title
        Me.year = year
        Me.author = author
        Me.genre = genre
        read = False
    End Sub

    Property PubTitle() As String
        Get
            Return title
        End Get
        Set(ByVal value As String)
            title = value
        End Set
    End Property

    Property PubYear() As Integer
        Get
            Return year
        End Get
        Set(ByVal value As Integer)
            year = value
        End Set
    End Property

    Property Completed() As Boolean
        Get
            Return read
        End Get
        Set(ByVal value As Boolean)
            read = value
        End Set
    End Property

    Function GetInfo() As String
        Dim info As String = ""
        info &= "Title: " & title & vbCrLf
        info &= "Publication Year: " & year & vbCrLf
        info &= "Author: " & author & vbCrLf
        info &= "Genre: " & genre & vbCrLf
        Return info
    End Function
End Class

